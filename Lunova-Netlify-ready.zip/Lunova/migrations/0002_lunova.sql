-- Lunova: light-novel publishing platform

create table if not exists profiles (
  user_id      text primary key,
  username     text not null unique,
  display_name text not null,
  bio          text not null default '',
  avatar_url   text,
  created_at   timestamptz not null default now()
);

create table if not exists novels (
  id           text primary key,
  slug         text not null unique,
  author_id    text not null,
  pen_name     text not null default '',
  title        text not null,
  synopsis     text not null default '',
  cover_url    text,
  genres       jsonb not null default '[]'::jsonb,
  tags         jsonb not null default '[]'::jsonb,
  age_rating   text not null default 'livre',
  status       text not null default 'ongoing',
  published    boolean not null default false,
  featured     boolean not null default false,
  likes_count  integer not null default 0,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists novels_author_id_idx on novels (author_id);
create index if not exists novels_published_idx on novels (published, created_at desc);
create index if not exists novels_likes_idx on novels (likes_count desc);

create table if not exists chapters (
  id            text primary key,
  novel_id      text not null references novels(id) on delete cascade,
  title         text not null,
  sort_order    integer not null default 0,
  content       jsonb not null default '{"blocks":[]}'::jsonb,
  status        text not null default 'draft',
  word_count    integer not null default 0,
  published_at  timestamptz,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists chapters_novel_id_idx on chapters (novel_id, sort_order);

create table if not exists media (
  id         text primary key,
  user_id    text not null,
  mime       text not null,
  data       text not null,
  created_at timestamptz not null default now()
);
create index if not exists media_user_id_idx on media (user_id);

create table if not exists library_items (
  user_id     text not null,
  novel_id    text not null references novels(id) on delete cascade,
  shelf       text not null default 'want',
  is_favorite boolean not null default false,
  created_at  timestamptz not null default now(),
  primary key (user_id, novel_id)
);
create index if not exists library_user_idx on library_items (user_id, shelf);

create table if not exists novel_likes (
  user_id    text not null,
  novel_id   text not null references novels(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, novel_id)
);

create table if not exists follows (
  follower_id text not null,
  author_id   text not null,
  created_at  timestamptz not null default now(),
  primary key (follower_id, author_id)
);
create index if not exists follows_author_idx on follows (author_id);

create table if not exists ratings (
  user_id    text not null,
  novel_id   text not null references novels(id) on delete cascade,
  stars      integer not null,
  created_at timestamptz not null default now(),
  primary key (user_id, novel_id)
);

create table if not exists comments (
  id         text primary key,
  chapter_id text not null references chapters(id) on delete cascade,
  user_id    text not null,
  body       text not null,
  created_at timestamptz not null default now()
);
create index if not exists comments_chapter_idx on comments (chapter_id, created_at);

create table if not exists reading_progress (
  user_id    text not null,
  novel_id   text not null references novels(id) on delete cascade,
  chapter_id text not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, novel_id)
);
