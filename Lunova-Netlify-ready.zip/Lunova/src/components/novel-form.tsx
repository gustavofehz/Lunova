import { useState, type FormEvent, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { AGE_RATINGS, GENRES, NOVEL_STATUSES } from "@/lib/constants";
import { compressImageFile } from "@/lib/image-file";
import { uploadMedia } from "@/lib/fn/media";
import type { NovelStatus } from "@/lib/types";
import { cn } from "@/lib/utils";
import { CoverImage } from "@/components/cover-card";

export type NovelFormValues = {
  title: string;
  synopsis: string;
  penName: string;
  genres: string[];
  tags: string[];
  ageRating: string;
  status: NovelStatus;
  coverUrl: string | null;
};

export function NovelForm({
  initial,
  submitLabel,
  onSubmit,
}: {
  initial: NovelFormValues;
  submitLabel: string;
  onSubmit: (values: NovelFormValues) => Promise<void>;
}) {
  const [values, setValues] = useState(initial);
  const [tagInput, setTagInput] = useState(initial.tags.join(", "));
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function toggleGenre(slug: string) {
    setValues((v) => {
      const has = v.genres.includes(slug);
      const genres = has ? v.genres.filter((g) => g !== slug) : [...v.genres, slug].slice(0, 5);
      return { ...v, genres };
    });
  }

  async function onCover(file: File | undefined) {
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const compressed = await compressImageFile(file, 900);
      const uploaded = await uploadMedia({ data: { mime: compressed.mime, data: compressed.data } });
      setValues((v) => ({ ...v, coverUrl: uploaded.url }));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Falha ao enviar a capa.");
    } finally {
      setUploading(false);
    }
  }

  async function handle(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const tags = tagInput
        .split(/[,#]/)
        .map((t) => t.trim())
        .filter(Boolean)
        .slice(0, 12);
      await onSubmit({ ...values, tags });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível salvar.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={(e) => void handle(e)} className="grid gap-8 md:grid-cols-[200px_1fr]">
      <div className="space-y-3">
        <CoverImage src={values.coverUrl} title={values.title || "Capa"} className="w-full rounded-xl" />
        <label className="inline-flex h-11 w-full cursor-pointer items-center justify-center rounded-lg border border-line bg-ink-3 text-sm">
          {uploading ? "Enviando capa…" : "Escolher capa"}
          <input
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp"
            className="sr-only"
            onChange={(e) => void onCover(e.target.files?.[0])}
          />
        </label>
        {values.coverUrl ? (
          <button
            type="button"
            className="w-full text-xs text-muted hover:text-seal"
            onClick={() => setValues((v) => ({ ...v, coverUrl: null }))}
          >
            Remover capa
          </button>
        ) : null}
      </div>

      <div className="space-y-5">
        <Field label="Título">
          <Input
            required
            value={values.title}
            onChange={(e) => setValues((v) => ({ ...v, title: e.target.value }))}
            placeholder="O nome da sua light novel"
          />
        </Field>
        <Field label="Autor (nome na obra)">
          <Input
            value={values.penName}
            onChange={(e) => setValues((v) => ({ ...v, penName: e.target.value }))}
            placeholder="Seu nome literário"
          />
        </Field>
        <Field label="Sinopse">
          <Textarea
            value={values.synopsis}
            onChange={(e) => setValues((v) => ({ ...v, synopsis: e.target.value }))}
            placeholder="O que o leitor encontra nesta história?"
            className="min-h-36"
          />
        </Field>
        <Field label="Gêneros (até 5)">
          <div className="flex flex-wrap gap-2">
            {GENRES.map((g) => {
              const on = values.genres.includes(g.slug);
              return (
                <button
                  key={g.slug}
                  type="button"
                  onClick={() => toggleGenre(g.slug)}
                  className={cn(
                    "h-9 rounded-full border px-3 text-sm",
                    on ? "border-seal bg-seal/15 text-paper" : "border-line text-muted hover:text-paper",
                  )}
                >
                  {g.label}
                </button>
              );
            })}
          </div>
        </Field>
        <Field label="Tags">
          <Input
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            placeholder="lua, santuário, destino"
          />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Classificação indicativa">
            <select
              value={values.ageRating}
              onChange={(e) => setValues((v) => ({ ...v, ageRating: e.target.value }))}
              className="h-11 w-full rounded-lg border border-line bg-ink-3 px-3 text-sm"
            >
              {AGE_RATINGS.map((r) => (
                <option key={r.value} value={r.value}>
                  {r.label}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Status">
            <select
              value={values.status}
              onChange={(e) => setValues((v) => ({ ...v, status: e.target.value as NovelStatus }))}
              className="h-11 w-full rounded-lg border border-line bg-ink-3 px-3 text-sm"
            >
              {NOVEL_STATUSES.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
          </Field>
        </div>
        {error ? <p className="text-sm text-seal">{error}</p> : null}
        <Button type="submit" disabled={busy || uploading} size="lg">
          {busy ? "Salvando…" : submitLabel}
        </Button>
      </div>
    </form>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block space-y-2">
      <span className="text-sm font-medium text-paper/80">{label}</span>
      {children}
    </label>
  );
}
