import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { BookMarked, Menu, PenLine, Search, X } from "lucide-react";
import { useState, type FormEvent, type ReactNode } from "react";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { authEnabled, signOut } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LunovaWordmark } from "@/components/logo";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const hideSearch = pathname.startsWith("/ler/") || pathname.includes("/capitulo/");

  function onSearch(e: FormEvent) {
    e.preventDefault();
    const query = q.trim();
    void navigate({ to: "/buscar", search: { q: query } });
    setOpen(false);
  }

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-ink/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4">
        <Link to="/" className="shrink-0" aria-label="Lunova, página inicial">
          <LunovaWordmark />
        </Link>

        {!hideSearch ? (
          <form onSubmit={onSearch} className="hidden min-w-0 flex-1 md:block">
            <label className="relative block">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar obras, autores, gêneros…"
                className="h-10 rounded-full border-line bg-ink-2 pl-9"
              />
            </label>
          </form>
        ) : (
          <div className="hidden flex-1 md:block" />
        )}

        <nav className="ml-auto flex items-center gap-1">
          <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
            <Link to="/explorar">Explorar</Link>
          </Button>
          {user ? (
            <>
              <Button asChild variant="ghost" size="sm" className="hidden sm:inline-flex">
                <Link to="/estudio">Estúdio</Link>
              </Button>
              <Button asChild variant="ghost" size="icon" className="hidden sm:inline-flex" aria-label="Biblioteca">
                <Link to="/biblioteca">
                  <BookMarked className="size-5" />
                </Link>
              </Button>
              <Button asChild variant="paper" size="sm" className="hidden sm:inline-flex">
                <Link to="/criar">
                  <PenLine className="size-4" />
                  Criar Light Novel
                </Link>
              </Button>
            </>
          ) : isPending ? (
            <div className="hidden h-9 w-36 animate-pulse rounded-lg bg-ink-3 sm:block" />
          ) : (
            <Button asChild variant="paper" size="sm" className="hidden sm:inline-flex">
              <Link to="/criar">Criar Light Novel</Link>
            </Button>
          )}
          <AuthSlot />
          <button
            type="button"
            className="grid size-11 place-items-center rounded-lg text-paper md:hidden"
            aria-label={open ? "Fechar menu" : "Abrir menu"}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
          </button>
        </nav>
      </div>

      {open ? (
        <div className="border-t border-line bg-ink px-4 py-4 md:hidden">
          <form onSubmit={onSearch} className="mb-3">
            <label className="relative block">
              <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar obras…"
                className="h-11 rounded-full pl-9"
              />
            </label>
          </form>
          <div className="flex flex-col gap-1">
            <Link to="/explorar" className="rounded-lg px-3 py-3 text-paper" onClick={() => setOpen(false)}>
              Explorar
            </Link>
            {user ? (
              <>
                <Link to="/biblioteca" className="rounded-lg px-3 py-3 text-paper" onClick={() => setOpen(false)}>
                  Biblioteca
                </Link>
                <Link to="/estudio" className="rounded-lg px-3 py-3 text-paper" onClick={() => setOpen(false)}>
                  Estúdio
                </Link>
                <Link to="/criar" className="rounded-lg px-3 py-3 text-paper" onClick={() => setOpen(false)}>
                  Criar Light Novel
                </Link>
              </>
            ) : (
              <Link to="/login" className="rounded-lg px-3 py-3 text-paper" onClick={() => setOpen(false)}>
                Entrar
              </Link>
            )}
          </div>
        </div>
      ) : null}
    </header>
  );
}

function AuthSlot() {
  const { user, isPending } = useCurrentUserState();
  const [signingOut, setSigningOut] = useState(false);
  const [menu, setMenu] = useState(false);
  const gateSession = typeof window !== "undefined" ? hasGateSessionMarker() : false;

  if (isPending) {
    return <div className="h-9 w-9 animate-pulse rounded-full bg-ink-3" />;
  }
  if (!user) {
    return (
      <Button asChild variant="outline" size="sm">
        <Link to="/login">Entrar</Link>
      </Button>
    );
  }

  const label = user.displayName ?? user.primaryEmail ?? "Conta";
  return (
    <div className="relative">
      <button
        type="button"
        className="flex size-9 items-center justify-center overflow-hidden rounded-full bg-ink-3 outline outline-1 outline-paper/15"
        aria-label="Conta"
        onClick={() => setMenu((v) => !v)}
      >
        {user.profileImageUrl ? (
          <img src={user.profileImageUrl} alt="" className="size-full object-cover" />
        ) : (
          <span className="text-sm font-medium">{label.charAt(0).toUpperCase()}</span>
        )}
      </button>
      {menu ? (
        <div className="absolute right-0 z-50 mt-2 w-52 overflow-hidden rounded-xl border border-line bg-ink-2 py-1 shadow-card">
          <Link
            to="/estudio"
            className="block px-3 py-2.5 text-sm text-paper hover:bg-ink-3"
            onClick={() => setMenu(false)}
          >
            Estúdio
          </Link>
          <Link
            to="/biblioteca"
            className="block px-3 py-2.5 text-sm text-paper hover:bg-ink-3"
            onClick={() => setMenu(false)}
          >
            Biblioteca
          </Link>
          <Link
            to="/conta"
            className="block px-3 py-2.5 text-sm text-paper hover:bg-ink-3"
            onClick={() => setMenu(false)}
          >
            Editar perfil
          </Link>
          {authEnabled && !gateSession ? (
            <button
              type="button"
              disabled={signingOut}
              className="block w-full px-3 py-2.5 text-left text-sm text-muted hover:bg-ink-3 hover:text-paper"
              onClick={() => {
                setSigningOut(true);
                void signOut("/").catch(() => setSigningOut(false));
              }}
            >
              {signingOut ? "Saindo…" : "Sair"}
            </button>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-16 border-t border-line">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-10 text-sm text-muted md:flex-row md:items-center md:justify-between">
        <p className="font-display text-lg text-paper/70">Lunova</p>
        <p>Uma casa para light novels — escrita, ilustrada e lida com calma.</p>
      </div>
    </footer>
  );
}

export function PageShell({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className="flex min-h-screen flex-col bg-ink text-paper">
      <SiteHeader />
      <main className={cn("mx-auto w-full max-w-6xl flex-1 px-4 py-8", className)}>{children}</main>
      <SiteFooter />
    </div>
  );
}
