import {
  AlignCenter,
  AlignJustify,
  AlignLeft,
  AlignRight,
  Bold,
  Heading2,
  ImagePlus,
  Italic,
  Minus,
  Trash2,
  Upload,
} from "lucide-react";
import { useCallback, useEffect, useRef, useState, type MouseEvent, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { compressImageFile } from "@/lib/image-file";
import { uploadMedia } from "@/lib/fn/media";
import { saveChapter } from "@/lib/fn/studio";
import { newBlockId, sanitizeHtml, wordCountOf } from "@/lib/chapter-content";
import type { ChapterBlock, ChapterContent, ImageAlign, TextAlign } from "@/lib/types";
import { cn } from "@/lib/utils";

type Props = {
  novelId: string;
  chapterId: string;
  novelTitle: string;
  initialTitle: string;
  initialContent: ChapterContent;
  initialStatus: "draft" | "published";
};

export function ChapterEditor({
  novelId,
  chapterId,
  novelTitle,
  initialTitle,
  initialContent,
  initialStatus,
}: Props) {
  const [title, setTitle] = useState(initialTitle);
  const [blocks, setBlocks] = useState<ChapterBlock[]>(
    initialContent.blocks.length ? initialContent.blocks : [para()],
  );
  const [status, setStatus] = useState(initialStatus);
  const [activeId, setActiveId] = useState<string | null>(blocks[0]?.id ?? null);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const snapshot = useRef({ title: initialTitle, blocks: initialContent.blocks });
  const titleRef = useRef<HTMLInputElement>(null);

  const persist = useCallback(
    async (opts?: { publish?: boolean; draft?: boolean }) => {
      setSaving(true);
      setError(null);
      try {
        const content: ChapterContent = { blocks: snapshot.current.blocks };
        const res = await saveChapter({
          data: {
            novelId,
            chapterId,
            title: snapshot.current.title,
            content,
            publish: opts?.publish,
            draft: opts?.draft,
          },
        });
        setStatus(res.status as "draft" | "published");
        setSavedAt(Date.now());
        setDirty(false);
      } catch (e) {
        setError(e instanceof Error ? e.message : "Não foi possível salvar.");
      } finally {
        setSaving(false);
      }
    },
    [novelId, chapterId],
  );

  useEffect(() => {
    snapshot.current = { title, blocks };
  }, [title, blocks]);

  useEffect(() => {
    if (!dirty) return;
    const t = window.setTimeout(() => {
      void persist();
    }, 1600);
    return () => window.clearTimeout(t);
  }, [dirty, title, blocks, persist]);

  useEffect(() => {
    titleRef.current?.focus();
  }, []);

  function update(id: string, patch: Partial<ChapterBlock>) {
    setBlocks((prev) => prev.map((b) => (b.id === id ? ({ ...b, ...patch } as ChapterBlock) : b)));
    setDirty(true);
  }

  function remove(id: string) {
    setBlocks((prev) => {
      const next = prev.filter((b) => b.id !== id);
      return next.length ? next : [para()];
    });
    setDirty(true);
  }

  function insertAfter(id: string | null, ...extra: ChapterBlock[]) {
    setBlocks((prev) => {
      const next = [...prev];
      if (!id) {
        next.push(...extra);
      } else {
        const i = next.findIndex((b) => b.id === id);
        next.splice(i < 0 ? next.length : i + 1, 0, ...extra);
      }
      return next;
    });
    setDirty(true);
    setActiveId(extra[extra.length - 1]?.id ?? id);
  }

  async function onPickImage(file: File | undefined) {
    if (!file) return;
    setUploading(true);
    setError(null);
    try {
      const compressed = await compressImageFile(file);
      const uploaded = await uploadMedia({ data: { mime: compressed.mime, data: compressed.data } });
      const image: ChapterBlock = {
        id: newBlockId(),
        type: "image",
        src: uploaded.url,
        align: "center",
        width: 86,
        caption: "",
      };
      insertAfter(activeId, image, para());
    } catch (e) {
      setError(e instanceof Error ? e.message : "Falha no envio da imagem.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  function applyInline(cmd: "bold" | "italic") {
    document.execCommand(cmd);
  }

  function setAlign(align: TextAlign) {
    if (!activeId) return;
    const b = blocks.find((x) => x.id === activeId);
    if (b?.type === "paragraph") update(activeId, { align });
  }

  function makeHeading() {
    if (!activeId) {
      insertAfter(null, { id: newBlockId(), type: "heading", level: 2, text: "" });
      return;
    }
    const b = blocks.find((x) => x.id === activeId);
    if (b?.type === "paragraph") {
      const tmp = document.createElement("div");
      tmp.innerHTML = b.html;
      update(activeId, { type: "heading", level: 2, text: tmp.textContent ?? "" } as Partial<ChapterBlock>);
    } else {
      insertAfter(activeId, { id: newBlockId(), type: "heading", level: 2, text: "" });
    }
  }

  const words = wordCountOf({ blocks });
  const savedLabel = saving
    ? "Salvando…"
    : error
      ? "Falha ao salvar"
      : savedAt && Date.now() - savedAt < 12_000
        ? "Salvo agora"
        : dirty
          ? "Alterações não salvas"
          : status === "published"
            ? "Publicado"
            : "Rascunho salvo";

  return (
    <div className="flex min-h-screen flex-col bg-ink text-paper">
      <div className="sticky top-0 z-30 border-b border-line bg-ink/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-3xl flex-wrap items-center gap-2 px-4 py-3">
          <Link
            to="/estudio/$novelId"
            params={{ novelId }}
            className="mr-auto min-w-0 truncate text-sm text-muted hover:text-paper"
          >
            ← {novelTitle}
          </Link>
          <span
            className={cn(
              "text-xs tabular-nums",
              error ? "text-seal" : "text-muted",
            )}
          >
            {savedLabel}
          </span>
          <Button
            type="button"
            variant="secondary"
            size="sm"
            onClick={() => void persist({ draft: true })}
            disabled={saving}
          >
            Salvar rascunho
          </Button>
          <Button
            type="button"
            size="sm"
            onClick={() => void persist({ publish: true })}
            disabled={saving}
          >
            {status === "published" ? "Atualizar" : "Publicar"}
          </Button>
        </div>
      </div>

      <div className="mx-auto w-full max-w-3xl flex-1 px-4 pt-8 pb-40">
        <input
          ref={titleRef}
          value={title}
          onChange={(e) => {
            setTitle(e.target.value);
            setDirty(true);
          }}
          placeholder="Título do capítulo"
          className="mb-2 w-full bg-transparent font-display text-4xl font-semibold tracking-tight text-paper outline-none placeholder:text-muted/50 md:text-5xl"
        />
        <p className="mb-8 text-sm text-muted">
          Clique abaixo e escreva. Use a barra inferior para negrito, títulos e ilustrações.
        </p>

        <div className="space-y-5" data-chapter-body>
          {blocks.map((block) => (
            <BlockView
              key={block.id}
              block={block}
              active={activeId === block.id}
              onFocus={() => setActiveId(block.id)}
              onChange={(patch) => update(block.id, patch)}
              onRemove={() => remove(block.id)}
              onEnter={() => insertAfter(block.id, para())}
            />
          ))}
        </div>
        <p className="mt-10 text-xs text-muted tabular-nums">{words} palavras</p>
        {error ? <p className="mt-3 text-sm text-seal">{error}</p> : null}
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-ink-2/95 pb-[max(0.5rem,env(safe-area-inset-bottom))] backdrop-blur-md">
        <div className="mx-auto flex max-w-3xl items-center gap-1 overflow-x-auto px-2 py-2">
          <ToolBtn label="Negrito" onMouseDown={(e) => { e.preventDefault(); applyInline("bold"); }}>
            <Bold className="size-4" />
          </ToolBtn>
          <ToolBtn label="Itálico" onMouseDown={(e) => { e.preventDefault(); applyInline("italic"); }}>
            <Italic className="size-4" />
          </ToolBtn>
          <ToolBtn label="Título" onClick={makeHeading}>
            <Heading2 className="size-4" />
          </ToolBtn>
          <span className="mx-1 h-6 w-px bg-line" />
          <ToolBtn label="Esquerda" onClick={() => setAlign("left")}>
            <AlignLeft className="size-4" />
          </ToolBtn>
          <ToolBtn label="Centro" onClick={() => setAlign("center")}>
            <AlignCenter className="size-4" />
          </ToolBtn>
          <ToolBtn label="Direita" onClick={() => setAlign("right")}>
            <AlignRight className="size-4" />
          </ToolBtn>
          <ToolBtn label="Justificar" onClick={() => setAlign("justify")}>
            <AlignJustify className="size-4" />
          </ToolBtn>
          <ToolBtn
            label="Separador de cena"
            onClick={() => insertAfter(activeId, { id: newBlockId(), type: "scene-break" })}
          >
            <Minus className="size-4" />
          </ToolBtn>
          <span className="mx-1 h-6 w-px bg-line" />
          <label className="inline-flex h-11 shrink-0 cursor-pointer items-center gap-2 rounded-lg bg-seal px-3 text-sm font-medium text-seal-fg">
            <ImagePlus className="size-4" />
            {uploading ? "Enviando…" : "Inserir ilustração"}
            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/jpg,image/png,image/webp"
              className="sr-only"
              onChange={(e) => void onPickImage(e.target.files?.[0])}
            />
          </label>
        </div>
      </div>
    </div>
  );
}

function para(): ChapterBlock {
  return { id: newBlockId(), type: "paragraph", html: "", align: "left" };
}

function ToolBtn({
  label,
  children,
  onClick,
  onMouseDown,
}: {
  label: string;
  children: ReactNode;
  onClick?: () => void;
  onMouseDown?: (e: MouseEvent) => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      onMouseDown={onMouseDown}
      className="grid size-11 shrink-0 place-items-center rounded-lg text-paper/80 hover:bg-ink-3 hover:text-paper"
    >
      {children}
    </button>
  );
}

function BlockView({
  block,
  active,
  onFocus,
  onChange,
  onRemove,
  onEnter,
}: {
  block: ChapterBlock;
  active: boolean;
  onFocus: () => void;
  onChange: (patch: Partial<ChapterBlock>) => void;
  onRemove: () => void;
  onEnter: () => void;
}) {
  if (block.type === "scene-break") {
    return (
      <div className="group relative py-2" onClick={onFocus}>
        <div className="scene-break">* * *</div>
        <button
          type="button"
          className="absolute top-1 right-0 hidden size-9 place-items-center rounded-md text-muted hover:text-seal group-hover:grid"
          aria-label="Remover separador"
          onClick={onRemove}
        >
          <Trash2 className="size-4" />
        </button>
      </div>
    );
  }

  if (block.type === "heading") {
    return (
      <div className="relative">
        <input
          value={block.text}
          onFocus={onFocus}
          onChange={(e) => onChange({ text: e.target.value })}
          placeholder="Subtítulo"
          className="w-full bg-transparent font-display text-2xl font-semibold tracking-tight text-paper outline-none placeholder:text-muted/50"
        />
      </div>
    );
  }

  if (block.type === "image") {
    return <ImageBlock block={block} onFocus={onFocus} onChange={onChange} onRemove={onRemove} />;
  }

  return (
    <EditableParagraph
      block={block}
      active={active}
      onFocus={onFocus}
      onChange={onChange}
      onEnter={onEnter}
    />
  );
}

function EditableParagraph({
  block,
  active,
  onFocus,
  onChange,
  onEnter,
}: {
  block: Extract<ChapterBlock, { type: "paragraph" }>;
  active?: boolean;
  onFocus: () => void;
  onChange: (patch: Partial<ChapterBlock>) => void;
  onEnter: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (ref.current && ref.current.innerHTML !== block.html) {
      if (document.activeElement !== ref.current) ref.current.innerHTML = block.html;
    }
  }, [block.html, block.id]);
  useEffect(() => {
    if (ref.current && !ref.current.innerHTML) ref.current.innerHTML = block.html;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [block.id]);

  const empty = !block.html || block.html === "<br>" || block.html === "<br/>";

  return (
    <div className="relative">
      {empty && !active ? (
        <span className="pointer-events-none absolute inset-0 font-reader text-lg leading-8 text-muted/55">
          Comece a escrever…
        </span>
      ) : null}
      <div
        ref={ref}
        contentEditable
        role="textbox"
        aria-label="Parágrafo"
        suppressContentEditableWarning
        onFocus={onFocus}
        onInput={() => {
          if (!ref.current) return;
          onChange({ html: sanitizeHtml(ref.current.innerHTML) });
        }}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            onEnter();
          }
        }}
        className={cn(
          "min-h-8 font-reader text-lg leading-8 text-paper/95 outline-none",
          block.align === "center" && "text-center",
          block.align === "right" && "text-right",
          block.align === "justify" && "text-justify",
        )}
      />
    </div>
  );
}

function ImageBlock({
  block,
  onFocus,
  onChange,
  onRemove,
}: {
  block: Extract<ChapterBlock, { type: "image" }>;
  onFocus: () => void;
  onChange: (patch: Partial<ChapterBlock>) => void;
  onRemove: () => void;
}) {
  const replaceRef = useRef<HTMLInputElement>(null);
  const [replacing, setReplacing] = useState(false);
  const [broken, setBroken] = useState(false);

  async function replace(file: File | undefined) {
    if (!file) return;
    setReplacing(true);
    try {
      const compressed = await compressImageFile(file);
      const uploaded = await uploadMedia({ data: { mime: compressed.mime, data: compressed.data } });
      onChange({ src: uploaded.url });
      setBroken(false);
    } finally {
      setReplacing(false);
      if (replaceRef.current) replaceRef.current.value = "";
    }
  }

  const align = block.align;
  return (
    <figure className="group space-y-2" onClick={onFocus}>
      <div
        className={cn(
          "flex",
          align === "left" && "justify-start",
          align === "center" && "justify-center",
          align === "right" && "justify-end",
        )}
      >
        <div style={{ width: `${block.width}%` }} className="relative max-w-full">
          {broken ? (
            <div className="grid aspect-video place-items-center rounded-lg bg-ink-3 text-sm text-muted">
              Não foi possível carregar a ilustração
            </div>
          ) : (
            <img
              src={block.src}
              alt={block.caption || "Ilustração do capítulo"}
              className="w-full rounded-lg outline outline-1 -outline-offset-1 outline-paper/10"
              onError={() => setBroken(true)}
            />
          )}
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <input
          type="range"
          min={40}
          max={100}
          value={block.width}
          aria-label="Tamanho da imagem"
          onChange={(e) => onChange({ width: Number(e.target.value) })}
          className="h-11 w-32 accent-seal"
        />
        {(["left", "center", "right"] as ImageAlign[]).map((a) => (
          <button
            key={a}
            type="button"
            onClick={() => onChange({ align: a })}
            className={cn(
              "h-9 rounded-md px-2.5 text-xs",
              align === a ? "bg-ink-4 text-paper" : "text-muted hover:text-paper",
            )}
          >
            {a === "left" ? "Esq." : a === "right" ? "Dir." : "Centro"}
          </button>
        ))}
        <label className="inline-flex h-9 cursor-pointer items-center gap-1 rounded-md px-2 text-xs text-muted hover:text-paper">
          <Upload className="size-3.5" />
          {replacing ? "Trocando…" : "Substituir"}
          <input
            ref={replaceRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp"
            className="sr-only"
            onChange={(e) => void replace(e.target.files?.[0])}
          />
        </label>
        <button
          type="button"
          onClick={onRemove}
          className="inline-flex h-9 items-center gap-1 rounded-md px-2 text-xs text-muted hover:text-seal"
        >
          <Trash2 className="size-3.5" />
          Excluir
        </button>
      </div>
      <Input
        value={block.caption}
        onChange={(e) => onChange({ caption: e.target.value })}
        placeholder="Legenda da imagem (opcional)"
        className="h-10 bg-ink-2 text-center italic"
      />
    </figure>
  );
}
