import { cn } from "@/lib/utils";

export function LunovaMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn("shrink-0", className)} aria-hidden>
      <rect width="32" height="32" rx="8" fill="currentColor" className="text-ink-3" />
      <path
        d="M20.2 7.2c-5.2.4-9.3 4.8-9.3 10.1 0 5.6 4.5 10.1 10.1 10.1 1.4 0 2.8-.3 4-.8C22.8 28.4 19 30 14.8 30 8.2 30 3 24.8 3 18.2 3 11.4 8.6 6 15.4 6c1.7 0 3.3.4 4.8 1.2z"
        className="fill-paper"
      />
      <path
        d="M11 21.5V12.8c0-.6.7-1 1.2-.7l7.4 4.3c.6.3.6 1.1 0 1.4l-7.4 4.4c-.5.3-1.2-.1-1.2-.7z"
        className="fill-seal"
      />
    </svg>
  );
}

export function LunovaWordmark({ className }: { className?: string }) {
  return (
    <span className={cn("flex items-center gap-2", className)}>
      <LunovaMark className="size-8" />
      <span className="font-display text-2xl font-semibold tracking-tight text-paper">Lunova</span>
    </span>
  );
}
