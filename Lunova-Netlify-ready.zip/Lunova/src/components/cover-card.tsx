import { Link } from "@tanstack/react-router";
import { BookOpen } from "lucide-react";
import { GENRE_LABEL, STATUS_LABEL } from "@/lib/constants";
import { displayedAuthor, type NovelCard } from "@/lib/types";
import { cn, formatCount } from "@/lib/utils";

export function CoverImage({
  src,
  title,
  className,
  fixed,
}: {
  src: string | null;
  title: string;
  className?: string;
  fixed?: boolean;
}) {
  return (
    <div
      className={cn(
        "relative overflow-hidden bg-ink-3 outline outline-1 -outline-offset-1 outline-paper/10",
        className,
      )}
      style={fixed ? undefined : { aspectRatio: "2 / 3" }}
    >
      {src ? (
        <img src={src} alt={`Capa de ${title}`} className="size-full object-cover" />
      ) : (
        <div className="flex size-full items-center justify-center bg-ink-4 font-display text-2xl text-paper/40">
          {title.slice(0, 1)}
        </div>
      )}
    </div>
  );
}

export function CoverCard({ novel, className }: { novel: NovelCard; className?: string }) {
  return (
    <Link
      to="/obra/$slug"
      params={{ slug: novel.slug }}
      className={cn("group flex flex-col gap-3 text-left", className)}
    >
      <CoverImage
        src={novel.coverUrl}
        title={novel.title}
        className="w-full rounded-xl transition-transform duration-250 ease-out group-hover:scale-[1.015]"
      />
      <div className="min-w-0">
        <h3 className="font-display text-lg font-semibold leading-snug tracking-tight text-paper group-hover:text-paper">
          {novel.title}
        </h3>
        <p className="mt-0.5 truncate text-sm text-muted">{displayedAuthor(novel)}</p>
        <div className="mt-1.5 flex items-center gap-2 text-xs text-muted">
          <span className="inline-flex items-center gap-1">
            <BookOpen className="size-3.5" />
            {novel.chapterCount} {novel.chapterCount === 1 ? "cap." : "caps."}
          </span>
          <span aria-hidden>·</span>
          <span>{STATUS_LABEL[novel.status] ?? novel.status}</span>
        </div>
      </div>
    </Link>
  );
}

export function GenreChip({
  slug,
  className,
}: {
  slug: string;
  className?: string;
}) {
  const label = GENRE_LABEL[slug] ?? slug;
  return (
    <Link
      to="/genero/$slug"
      params={{ slug }}
      className={cn(
        "inline-flex h-8 items-center rounded-full border border-line px-3 text-xs font-medium text-paper/80 hover:border-line-strong hover:bg-ink-3",
        className,
      )}
    >
      {label}
    </Link>
  );
}

export function NovelRail({
  title,
  novels,
  href,
}: {
  title: string;
  novels: NovelCard[];
  href?: string;
}) {
  if (!novels.length) return null;
  return (
    <section className="space-y-4">
      <div className="flex items-end justify-between gap-3">
        <h2 className="font-display text-2xl font-semibold tracking-tight text-paper md:text-3xl">
          {title}
        </h2>
        {href ? (
          <Link to={href} className="text-sm text-muted hover:text-paper">
            Ver todas
          </Link>
        ) : null}
      </div>
      <div className="hide-scrollbar -mx-4 flex gap-4 overflow-x-auto px-4 pb-2 md:mx-0 md:grid md:grid-cols-4 md:overflow-visible md:px-0 lg:grid-cols-5">
        {novels.map((n) => (
          <div key={n.id} className="w-[42vw] max-w-[200px] shrink-0 md:w-auto md:max-w-none">
            <CoverCard novel={n} />
          </div>
        ))}
      </div>
    </section>
  );
}

export function formatCountSafe(n: number) {
  return formatCount(n);
}
