import { Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Moon, Sun, Type } from "lucide-react";
import { useEffect, useState } from "react";
import { displayedAuthor, type ChapterBlock, type ChapterDetail, type ChapterMeta, type NovelCard } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const FONT_SIZES = [16, 18, 20, 22, 24] as const;

export function ChapterReader({
  novel,
  chapter,
  prev,
  next,
}: {
  novel: NovelCard;
  chapter: ChapterDetail;
  prev: ChapterMeta | null;
  next: ChapterMeta | null;
}) {
  const [theme, setTheme] = useState<"paper" | "night">("paper");
  const [font, setFont] = useState<(typeof FONT_SIZES)[number]>(18);

  useEffect(() => {
    try {
      const t = localStorage.getItem("lunova-reader-theme");
      const f = Number(localStorage.getItem("lunova-reader-font"));
      if (t === "paper" || t === "night") setTheme(t);
      if (FONT_SIZES.includes(f as (typeof FONT_SIZES)[number])) setFont(f as (typeof FONT_SIZES)[number]);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem("lunova-reader-theme", theme);
      localStorage.setItem("lunova-reader-font", String(font));
    } catch {
      /* ignore */
    }
  }, [theme, font]);

  return (
    <div className={cn("min-h-screen", theme === "paper" ? "reader-paper" : "reader-night")}>
      <div className="sticky top-0 z-20 border-b border-current/10 bg-inherit/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-3xl items-center gap-2 px-4">
          <Link
            to="/obra/$slug"
            params={{ slug: novel.slug }}
            className="inline-flex size-11 items-center justify-center rounded-lg"
            aria-label="Voltar à obra"
          >
            <ChevronLeft className="size-5" />
          </Link>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-sm font-semibold">{novel.title}</p>
            <p className="truncate text-xs opacity-60">{chapter.title}</p>
          </div>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-lg"
            aria-label="Tamanho da fonte"
            onClick={() => {
              const i = FONT_SIZES.indexOf(font);
              setFont(FONT_SIZES[(i + 1) % FONT_SIZES.length] ?? 18);
            }}
          >
            <Type className="size-4" />
          </button>
          <button
            type="button"
            className="grid size-11 place-items-center rounded-lg"
            aria-label={theme === "paper" ? "Modo escuro" : "Modo claro"}
            onClick={() => setTheme((t) => (t === "paper" ? "night" : "paper"))}
          >
            {theme === "paper" ? <Moon className="size-4" /> : <Sun className="size-4" />}
          </button>
        </div>
      </div>

      <article className="mx-auto max-w-2xl px-5 py-10">
        <p className="text-xs tracking-widest uppercase opacity-50">{displayedAuthor(novel)}</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">{chapter.title}</h1>
        <div className="mt-10 space-y-6" style={{ fontSize: font, lineHeight: 1.75 }}>
          {chapter.content.blocks.map((b) => (
            <ReaderBlock key={b.id} block={b} />
          ))}
        </div>
      </article>

      <nav className="mx-auto flex max-w-2xl items-stretch gap-3 px-5 pb-16">
        {prev ? (
          <Button asChild variant={theme === "paper" ? "secondary" : "outline"} className="flex-1 justify-start">
            <Link to="/ler/$slug/$chapterId" params={{ slug: novel.slug, chapterId: prev.id }}>
              <ChevronLeft className="size-4" />
              <span className="truncate">{prev.title}</span>
            </Link>
          </Button>
        ) : (
          <div className="flex-1" />
        )}
        {next ? (
          <Button asChild variant="primary" className="flex-1 justify-end">
            <Link to="/ler/$slug/$chapterId" params={{ slug: novel.slug, chapterId: next.id }}>
              <span className="truncate">{next.title}</span>
              <ChevronRight className="size-4" />
            </Link>
          </Button>
        ) : (
          <Button asChild variant="paper" className="flex-1">
            <Link to="/obra/$slug" params={{ slug: novel.slug }}>
              Fim desta leitura
            </Link>
          </Button>
        )}
      </nav>
    </div>
  );
}

function ReaderBlock({ block }: { block: ChapterBlock }) {
  if (block.type === "scene-break") {
    return <div className="scene-break py-4">* * *</div>;
  }
  if (block.type === "heading") {
    const Tag = block.level === 3 ? "h3" : "h2";
    return <Tag className="font-display text-[1.35em] font-semibold tracking-tight">{block.text}</Tag>;
  }
  if (block.type === "image") {
    return (
      <figure
        className={cn(
          "my-8 flex flex-col gap-2",
          block.align === "left" && "items-start",
          block.align === "center" && "items-center",
          block.align === "right" && "items-end",
        )}
      >
        <img
          src={block.src}
          alt={block.caption || ""}
          style={{ width: `${block.width}%` }}
          className="max-w-full rounded-lg outline outline-1 -outline-offset-1 outline-current/10"
        />
        {block.caption ? (
          <figcaption className="max-w-prose text-center text-[0.8em] italic opacity-70">{block.caption}</figcaption>
        ) : null}
      </figure>
    );
  }
  return (
    <p
      className={cn(
        "font-reader",
        block.align === "center" && "text-center",
        block.align === "right" && "text-right",
        block.align === "justify" && "text-justify",
      )}
      dangerouslySetInnerHTML={{ __html: block.html || "&nbsp;" }}
    />
  );
}
