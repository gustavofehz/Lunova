import type { InputHTMLAttributes, TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-lg border border-line bg-ink-3 px-3 text-sm text-paper placeholder:text-muted",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-seal/60",
        className,
      )}
      {...props}
    />
  );
}

export function Textarea({ className, ...props }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={cn(
        "min-h-28 w-full rounded-lg border border-line bg-ink-3 px-3 py-2.5 text-sm text-paper placeholder:text-muted",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-seal/60",
        className,
      )}
      {...props}
    />
  );
}
