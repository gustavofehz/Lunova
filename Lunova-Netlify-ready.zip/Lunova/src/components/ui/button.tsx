import { cva, type VariantProps } from "class-variance-authority";
import { Slot } from "@radix-ui/react-slot";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-medium whitespace-nowrap transition-[background-color,color,transform,opacity] duration-150 ease-out active:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-seal/70",
  {
    variants: {
      variant: {
        primary: "bg-seal text-seal-fg hover:bg-seal-2",
        paper: "bg-paper text-ink hover:bg-paper-2",
        secondary: "bg-ink-3 text-paper border border-line hover:bg-ink-4",
        ghost: "text-paper/85 hover:bg-ink-3 hover:text-paper",
        outline: "border border-line-strong text-paper hover:bg-ink-3",
        danger: "bg-seal/15 text-seal hover:bg-seal/25",
      },
      size: {
        sm: "h-9 px-3 text-sm rounded-md",
        md: "h-11 px-4 text-sm rounded-lg",
        lg: "h-12 px-5 text-base rounded-xl",
        icon: "size-11 rounded-lg",
        pill: "h-10 px-4 text-sm rounded-full",
      },
    },
    defaultVariants: { variant: "primary", size: "md" },
  },
);

type Props = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean };

export function Button({ className, variant, size, asChild, ...props }: Props) {
  const Comp = asChild ? Slot : "button";
  return <Comp className={cn(buttonVariants({ variant, size }), className)} {...props} />;
}
