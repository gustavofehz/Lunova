import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { ArrowDown, ArrowUp, PenLine } from "lucide-react";
import { toast } from "sonner";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { PageShell } from "@/components/header";
import { NovelForm } from "@/components/novel-form";
import { Button } from "@/components/ui/button";
import { createChapter, deleteChapter, getStudioNovel, reorderChapters, updateNovel } from "@/lib/fn/studio";
import { formatCount } from "@/lib/utils";

export const Route = createFileRoute("/estudio_/$novelId")({ component: StudioNovelPage });

function StudioNovelPage() {
  const { novelId } = Route.useParams();
  const { user, isPending: authPending } = useCurrentUserState();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const { data, isPending } = useQuery({
    queryKey: ["studio-novel", novelId],
    queryFn: () => getStudioNovel({ data: { id: novelId } }),
    enabled: !!user,
  });

  const saveMut = useMutation({
    mutationFn: (published: boolean) =>
      updateNovel({
        data: {
          id: novelId,
          title: data!.novel.title,
          synopsis: data!.novel.synopsis,
          penName: data!.novel.penName,
          genres: data!.novel.genres,
          tags: data!.novel.tags,
          ageRating: data!.novel.ageRating,
          status: data!.novel.status,
          coverUrl: data!.novel.coverUrl,
          published,
        },
      }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["studio-novel", novelId] }),
  });

  async function openChapter(chapterId: string) {
    await navigate({
      to: "/estudio/$novelId/capitulo/$chapterId",
      params: { novelId, chapterId },
    });
  }

  async function newChapter() {
    try {
      const res = await createChapter({ data: { novelId } });
      await navigate({
        to: "/estudio/$novelId/capitulo/$chapterId",
        params: { novelId, chapterId: res.id },
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Não foi possível criar o capítulo.");
    }
  }

  async function move(index: number, dir: -1 | 1) {
    if (!data) return;
    const ids = data.chapters.map((c) => c.id);
    const j = index + dir;
    if (j < 0 || j >= ids.length) return;
    const swap = ids[index]!;
    ids[index] = ids[j]!;
    ids[j] = swap;
    await reorderChapters({ data: { novelId, orderedIds: ids } });
    await qc.invalidateQueries({ queryKey: ["studio-novel", novelId] });
  }

  if (authPending) {
    return (
      <PageShell>
        <div className="h-10 w-40 animate-pulse rounded-lg bg-ink-3" />
      </PageShell>
    );
  }
  if (!user) return <RedirectToSignIn />;
  if (isPending) {
    return (
      <PageShell>
        <p className="text-muted">Carregando obra…</p>
      </PageShell>
    );
  }
  if (!data) {
    return (
      <PageShell>
        <h1 className="font-display text-3xl">Obra não encontrada</h1>
        <p className="mt-2 text-sm text-muted">Ela pode ter sido excluída, ou você não é o autor.</p>
        <Button asChild className="mt-6">
          <Link to="/estudio">Voltar ao estúdio</Link>
        </Button>
      </PageShell>
    );
  }

  const { novel, chapters, readers } = data;

  return (
    <PageShell className="max-w-4xl space-y-12">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Link to="/estudio" className="text-sm text-muted hover:text-paper">
            ← Estúdio
          </Link>
          <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">{novel.title}</h1>
          <p className="mt-1 text-sm text-muted">
            {formatCount(novel.likesCount)} curtidas · {formatCount(readers)} leitores ·{" "}
            {novel.published ? "visível no catálogo" : "ainda não publicada"}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button type="button" onClick={() => void (chapters[0] ? openChapter(chapters[0].id) : newChapter())}>
            <PenLine className="size-4" />
            {chapters.length ? "Continuar escrevendo" : "Escrever capítulo"}
          </Button>
          <Button
            variant="secondary"
            onClick={() => saveMut.mutate(!novel.published)}
            disabled={saveMut.isPending}
          >
            {novel.published ? "Ocultar do catálogo" : "Publicar obra"}
          </Button>
          {novel.published ? (
            <Button asChild variant="outline">
              <Link to="/obra/$slug" params={{ slug: novel.slug }}>
                Ver página
              </Link>
            </Button>
          ) : null}
        </div>
      </div>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-semibold">Capítulos</h2>
          <Button onClick={() => void newChapter()}>
            <PenLine className="size-4" />
            Novo capítulo
          </Button>
        </div>
        <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line">
          {chapters.length === 0 ? (
            <li className="px-4 py-10 text-center">
              <p className="text-sm text-muted">Nenhum capítulo ainda. Escreva o primeiro — e insira imagens no meio da cena.</p>
              <Button className="mt-4" onClick={() => void newChapter()}>
                Escrever o primeiro capítulo
              </Button>
            </li>
          ) : (
            chapters.map((c, i) => (
              <li key={c.id} className="flex items-center gap-2 px-3 py-3">
                <div className="flex flex-col">
                  <button type="button" className="grid size-8 place-items-center text-muted" onClick={() => void move(i, -1)} aria-label="Subir">
                    <ArrowUp className="size-4" />
                  </button>
                  <button type="button" className="grid size-8 place-items-center text-muted" onClick={() => void move(i, 1)} aria-label="Descer">
                    <ArrowDown className="size-4" />
                  </button>
                </div>
                <Link
                  to="/estudio/$novelId/capitulo/$chapterId"
                  params={{ novelId, chapterId: c.id }}
                  className="min-w-0 flex-1"
                >
                  <p className="truncate font-medium">{c.title}</p>
                  <p className="text-xs text-muted">
                    {c.status === "published" ? "Publicado" : "Rascunho"} · {c.wordCount} palavras
                  </p>
                </Link>
                <Button
                  type="button"
                  size="sm"
                  variant="secondary"
                  onClick={() => void openChapter(c.id)}
                >
                  Escrever
                </Button>
                <button
                  type="button"
                  className="px-2 text-xs text-muted hover:text-seal"
                  onClick={async () => {
                    if (!confirm("Excluir este capítulo?")) return;
                    await deleteChapter({ data: { novelId, chapterId: c.id } });
                    toast("Capítulo excluído.");
                    await qc.invalidateQueries({ queryKey: ["studio-novel", novelId] });
                  }}
                >
                  Excluir
                </button>
              </li>
            ))
          )}
        </ul>
      </section>

      <section className="space-y-4">
        <h2 className="font-display text-2xl font-semibold">Informações da obra</h2>
        <NovelForm
          initial={{
            title: novel.title,
            synopsis: novel.synopsis,
            penName: novel.penName,
            genres: novel.genres,
            tags: novel.tags,
            ageRating: novel.ageRating,
            status: novel.status,
            coverUrl: novel.coverUrl,
          }}
          submitLabel="Salvar alterações"
          onSubmit={async (values) => {
            await updateNovel({
              data: {
                id: novelId,
                ...values,
                published: novel.published,
              },
            });
            toast("Obra atualizada.");
            await qc.invalidateQueries({ queryKey: ["studio-novel", novelId] });
          }}
        />
      </section>
    </PageShell>
  );
}
