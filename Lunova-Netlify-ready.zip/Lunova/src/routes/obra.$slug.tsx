import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Bookmark, Heart, MessageCircle, Share2, Star, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { CoverImage, GenreChip } from "@/components/cover-card";
import { PageShell } from "@/components/header";
import { Button } from "@/components/ui/button";
import { getNovelBySlug } from "@/lib/fn/catalog";
import { setLibrary, setRating, toggleFollow, toggleLike } from "@/lib/fn/social";
import { AGE_RATING_LABEL, SHELVES, STATUS_LABEL } from "@/lib/constants";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { displayedAuthor } from "@/lib/types";
import { cn, formatCount } from "@/lib/utils";

export const Route = createFileRoute("/obra/$slug")({ component: ObraPage });

function ObraPage() {
  const { slug } = Route.useParams();
  const qc = useQueryClient();
  const { user, isPending: authPending } = useCurrentUserState();
  const { data, isPending } = useQuery({
    queryKey: ["novel", slug],
    queryFn: () => getNovelBySlug({ data: { slug } }),
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["novel", slug] });

  const likeMut = useMutation({
    mutationFn: () => toggleLike({ data: { novelId: data!.novel.id } }),
    onSuccess: invalidate,
  });
  const followMut = useMutation({
    mutationFn: () => toggleFollow({ data: { authorId: data!.novel.authorId } }),
    onSuccess: invalidate,
  });
  const rateMut = useMutation({
    mutationFn: (stars: number) => setRating({ data: { novelId: data!.novel.id, stars } }),
    onSuccess: invalidate,
  });
  const libMut = useMutation({
    mutationFn: (payload: { shelf?: "reading" | "want" | "completed" | null; favorite?: boolean }) =>
      setLibrary({ data: { novelId: data!.novel.id, ...payload } }),
    onSuccess: () => {
      invalidate();
      void qc.invalidateQueries({ queryKey: ["library"] });
    },
  });

  if (isPending) {
    return (
      <PageShell>
        <p className="text-muted">Abrindo a obra…</p>
      </PageShell>
    );
  }
  if (!data) {
    return (
      <PageShell>
        <h1 className="font-display text-3xl">Obra não encontrada</h1>
      </PageShell>
    );
  }

  const { novel, chapters } = data;
  const publishedChapters = chapters.filter((c) => c.status === "published");
  const first = publishedChapters[0];
  const needAuth = () => {
    if (authPending) return true;
    if (!user) {
      toast("Entre para interagir com as obras.");
      return true;
    }
    return false;
  };

  async function share() {
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: novel.title, url });
      } else {
        await navigator.clipboard.writeText(url);
        toast("Link copiado.");
      }
    } catch {
      await navigator.clipboard.writeText(url);
      toast("Link copiado.");
    }
  }

  return (
    <PageShell className="max-w-5xl">
      <div className="grid gap-8 md:grid-cols-[220px_1fr] lg:grid-cols-[260px_1fr]">
        <CoverImage src={novel.coverUrl} title={novel.title} className="mx-auto w-56 rounded-2xl md:w-full" />
        <div>
          <div className="flex flex-wrap gap-2">
            {novel.genres.map((g) => (
              <GenreChip key={g} slug={g} />
            ))}
          </div>
          <h1 className="mt-3 font-display text-4xl font-semibold tracking-tight md:text-5xl">{novel.title}</h1>
          <p className="mt-2 text-muted">
            por{" "}
            <Link to="/u/$username" params={{ username: novel.authorUsername }} className="text-paper hover:underline">
              {displayedAuthor(novel)}
            </Link>
            <span className="mx-2">·</span>
            {STATUS_LABEL[novel.status]}
            <span className="mx-2">·</span>
            {AGE_RATING_LABEL[novel.ageRating] ?? novel.ageRating}
          </p>
          <p className="mt-5 max-w-2xl text-base leading-relaxed text-paper/80">{novel.synopsis}</p>
          <div className="mt-4 flex flex-wrap gap-4 text-sm text-muted">
            <span>{publishedChapters.length} capítulos</span>
            <span>{formatCount(novel.likesCount)} curtidas</span>
            <span>{formatCount(data.readers)} leitores</span>
            {novel.ratingAvg ? (
              <span>
                {novel.ratingAvg.toFixed(1)} · {novel.ratingCount} avaliações
              </span>
            ) : null}
          </div>
          {novel.tags.length ? (
            <p className="mt-3 text-sm text-muted">{novel.tags.map((t) => `#${t}`).join("  ")}</p>
          ) : null}

          <div className="mt-8 flex flex-wrap gap-2">
            {first ? (
              <Button asChild size="lg">
                <Link to="/ler/$slug/$chapterId" params={{ slug: novel.slug, chapterId: first.id }}>
                  Começar a ler
                </Link>
              </Button>
            ) : (
              <Button size="lg" disabled>
                Ainda sem capítulos
              </Button>
            )}
            <Button
              variant={data.liked ? "primary" : "secondary"}
              onClick={() => {
                if (needAuth()) return;
                likeMut.mutate();
              }}
            >
              <Heart className={cn("size-4", data.liked && "fill-current")} />
              Curtir
            </Button>
            <Button
              variant={data.isFavorite ? "primary" : "secondary"}
              onClick={() => {
                if (needAuth()) return;
                libMut.mutate({ favorite: !data.isFavorite, shelf: (data.shelf as "want") || "want" });
              }}
            >
              <Bookmark className={cn("size-4", data.isFavorite && "fill-current")} />
              Favoritar
            </Button>
            <Button
              variant={data.following ? "primary" : "secondary"}
              onClick={() => {
                if (needAuth()) return;
                followMut.mutate();
              }}
            >
              <UserPlus className="size-4" />
              {data.following ? "Seguindo" : "Seguir autor"}
            </Button>
            <Button variant="ghost" onClick={() => void share()}>
              <Share2 className="size-4" />
              Compartilhar
            </Button>
          </div>

          <div className="mt-6 flex flex-wrap items-center gap-2">
            <span className="text-sm text-muted">Estante:</span>
            {SHELVES.map((s) => (
              <button
                key={s.value}
                type="button"
                className={cn(
                  "h-9 rounded-full border px-3 text-sm",
                  data.shelf === s.value ? "border-seal bg-seal/15 text-paper" : "border-line text-muted",
                )}
                onClick={() => {
                  if (needAuth()) return;
                  libMut.mutate({ shelf: s.value, favorite: data.isFavorite });
                }}
              >
                {s.label}
              </button>
            ))}
          </div>

          <div className="mt-5 flex items-center gap-1">
            <span className="mr-2 text-sm text-muted">Avaliar:</span>
            {[1, 2, 3, 4, 5].map((n) => (
              <button
                key={n}
                type="button"
                aria-label={`${n} estrelas`}
                className="grid size-9 place-items-center"
                onClick={() => {
                  if (needAuth()) return;
                  rateMut.mutate(n);
                }}
              >
                <Star
                  className={cn(
                    "size-5",
                    (data.myRating ?? 0) >= n ? "fill-seal text-seal" : "text-muted",
                  )}
                />
              </button>
            ))}
          </div>
        </div>
      </div>

      <section className="mt-14">
        <h2 className="font-display text-2xl font-semibold">Capítulos</h2>
        <ol className="mt-4 divide-y divide-line overflow-hidden rounded-2xl border border-line">
          {publishedChapters.length === 0 ? (
            <li className="px-4 py-8 text-sm text-muted">Nenhum capítulo publicado ainda.</li>
          ) : (
            publishedChapters.map((c, i) => (
              <li key={c.id}>
                <Link
                  to="/ler/$slug/$chapterId"
                  params={{ slug: novel.slug, chapterId: c.id }}
                  className="flex items-center gap-4 px-4 py-4 hover:bg-ink-2"
                >
                  <span className="w-8 text-sm tabular-nums text-muted">{i + 1}</span>
                  <span className="flex-1 font-medium">{c.title}</span>
                  <span className="text-xs text-muted">{c.wordCount} palavras</span>
                </Link>
              </li>
            ))
          )}
        </ol>
      </section>
      <p className="mt-6 hidden text-xs text-muted">
        <MessageCircle className="mr-1 inline size-3.5" />
        Comentários ficam em cada capítulo.
      </p>
    </PageShell>
  );
}
