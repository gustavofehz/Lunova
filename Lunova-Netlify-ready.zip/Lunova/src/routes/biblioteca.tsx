import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { CoverCard } from "@/components/cover-card";
import { PageShell } from "@/components/header";
import { getLibrary } from "@/lib/fn/social";
import { SHELVES } from "@/lib/constants";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/biblioteca")({ component: BibliotecaPage });

function BibliotecaPage() {
  const { user, isPending: authPending } = useCurrentUserState();
  const { data, isPending } = useQuery({
    queryKey: ["library"],
    queryFn: () => getLibrary(),
    enabled: !!user,
  });
  const [tab, setTab] = useState<"favorites" | "reading" | "want" | "completed">("reading");

  if (authPending) {
    return (
      <PageShell>
        <div className="h-10 w-40 animate-pulse rounded-lg bg-ink-3" />
      </PageShell>
    );
  }
  if (!user) return <RedirectToSignIn />;

  const list =
    tab === "favorites"
      ? (data ?? []).filter((n) => n.isFavorite)
      : (data ?? []).filter((n) => n.shelf === tab);

  return (
    <PageShell className="space-y-8">
      <header>
        <p className="text-xs tracking-[0.28em] text-seal uppercase">Sua estante</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">Biblioteca</h1>
      </header>
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          onClick={() => setTab("favorites")}
          className={cn(
            "h-10 rounded-full border px-4 text-sm",
            tab === "favorites" ? "border-seal bg-seal/15 text-paper" : "border-line text-muted",
          )}
        >
          Favoritos
        </button>
        {SHELVES.map((s) => (
          <button
            key={s.value}
            type="button"
            onClick={() => setTab(s.value)}
            className={cn(
              "h-10 rounded-full border px-4 text-sm",
              tab === s.value ? "border-seal bg-seal/15 text-paper" : "border-line text-muted",
            )}
          >
            {s.label}
          </button>
        ))}
      </div>
      {isPending ? (
        <p className="text-muted">Abrindo a biblioteca…</p>
      ) : list.length === 0 ? (
        <p className="text-muted">Nada por aqui ainda. Explore o catálogo e adicione obras à sua estante.</p>
      ) : (
        <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {list.map((n) => (
            <CoverCard key={n.id} novel={n} />
          ))}
        </div>
      )}
    </PageShell>
  );
}
