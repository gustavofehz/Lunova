import { useMutation, useQuery } from "@tanstack/react-query";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { PageShell } from "@/components/header";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { getMe, updateMe } from "@/lib/fn/profile";
import { uploadMedia } from "@/lib/fn/media";
import { compressImageFile } from "@/lib/image-file";

export const Route = createFileRoute("/conta")({ component: ContaPage });

function ContaPage() {
  const { user, isPending: authPending } = useCurrentUserState();
  const navigate = useNavigate();
  const { data } = useQuery({
    queryKey: ["me"],
    queryFn: () => getMe(),
    enabled: !!user,
  });
  const [displayName, setDisplayName] = useState("");
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!data) return;
    setDisplayName(data.display_name);
    setUsername(data.username);
    setBio(data.bio);
    setAvatarUrl(data.avatar_url);
  }, [data]);

  const saveMut = useMutation({
    mutationFn: () => updateMe({ data: { displayName, username, bio, avatarUrl } }),
    onSuccess: (res) => {
      toast("Perfil atualizado.");
      void navigate({ to: "/u/$username", params: { username: res.username } });
    },
    onError: (e) => toast(e instanceof Error ? e.message : "Falha ao salvar."),
  });

  if (authPending) {
    return (
      <PageShell>
        <div className="h-10 w-40 animate-pulse rounded-lg bg-ink-3" />
      </PageShell>
    );
  }
  if (!user) return <RedirectToSignIn />;

  return (
    <PageShell className="max-w-xl space-y-8">
      <header>
        <p className="text-xs tracking-[0.28em] text-seal uppercase">Conta</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">Seu perfil</h1>
      </header>
      <div className="space-y-5">
        <div className="flex items-center gap-4">
          <div className="grid size-16 place-items-center overflow-hidden rounded-full bg-ink-3 font-display text-2xl">
            {avatarUrl ? <img src={avatarUrl} alt="" className="size-full object-cover" /> : displayName.slice(0, 1) || "A"}
          </div>
          <label className="inline-flex h-11 cursor-pointer items-center rounded-lg border border-line px-3 text-sm">
            Trocar foto
            <input
              type="file"
              accept="image/jpeg,image/jpg,image/png,image/webp"
              className="sr-only"
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file) return;
                try {
                  const compressed = await compressImageFile(file, 600);
                  const uploaded = await uploadMedia({ data: { mime: compressed.mime, data: compressed.data } });
                  setAvatarUrl(uploaded.url);
                } catch (err) {
                  toast(err instanceof Error ? err.message : "Falha no envio.");
                }
              }}
            />
          </label>
        </div>
        <label className="block space-y-2">
          <span className="text-sm">Nome</span>
          <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
        </label>
        <label className="block space-y-2">
          <span className="text-sm">Usuário</span>
          <Input value={username} onChange={(e) => setUsername(e.target.value)} />
        </label>
        <label className="block space-y-2">
          <span className="text-sm">Biografia</span>
          <Textarea value={bio} onChange={(e) => setBio(e.target.value)} maxLength={600} />
        </label>
        <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>
          Salvar perfil
        </Button>
      </div>
    </PageShell>
  );
}
