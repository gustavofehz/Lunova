import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { LunovaWordmark } from "@/components/logo";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!isPending && user) {
    void navigate({ to: "/" });
  }

  async function onEmail(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      if (mode === "up") {
        const { error: err } = await authClient.signUp.email({ email, password, name: name.trim() || email.split("@")[0] });
        if (err) throw new Error(err.message ?? "Não foi possível criar a conta.");
      } else {
        const { error: err } = await authClient.signIn.email({ email, password });
        if (err) throw new Error(err.message ?? "E-mail ou senha inválidos.");
      }
      await authClient.getSession();
      void navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Falha na autenticação.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen bg-ink lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-ink-2 lg:block">
        <div className="seigaiha absolute inset-0" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
        <div className="relative flex h-full flex-col justify-end p-12">
          <p className="font-display text-5xl font-semibold text-paper">Escreva o capítulo que só você pode contar.</p>
          <p className="mt-4 max-w-md text-paper/75">Lunova é uma casa para light novels — texto, imagem e leitores no mesmo lugar.</p>
        </div>
      </div>
      <div className="flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-sm space-y-6">
          <Link to="/" className="inline-block">
            <LunovaWordmark />
          </Link>
          <div>
            <h1 className="font-display text-3xl font-semibold">{mode === "in" ? "Entrar" : "Criar conta"}</h1>
            <p className="mt-1 text-sm text-muted">
              {mode === "in" ? "Acesse sua biblioteca e o estúdio." : "Publique sua primeira light novel hoje."}
            </p>
          </div>

          {authEnabled ? (
            <>
              <div className="space-y-2">
                {GROK_PROVIDERS.map((p) => (
                  <Button
                    key={p.providerId}
                    type="button"
                    variant="secondary"
                    className="w-full"
                    onClick={() => void signIn(p.providerId, { callbackURL: "/" })}
                  >
                    Continuar com {p.label}
                  </Button>
                ))}
              </div>
              <div className="flex items-center gap-3 text-xs text-muted">
                <span className="h-px flex-1 bg-line" />
                ou com e-mail
                <span className="h-px flex-1 bg-line" />
              </div>
              <form onSubmit={(e) => void onEmail(e)} className="space-y-3">
                {mode === "up" ? (
                  <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome" autoComplete="name" />
                ) : null}
                <Input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="E-mail"
                  autoComplete="email"
                />
                <Input
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Senha (mín. 8 caracteres)"
                  autoComplete={mode === "up" ? "new-password" : "current-password"}
                />
                {error ? <p className="text-sm text-seal">{error}</p> : null}
                <Button type="submit" className="w-full" disabled={busy}>
                  {busy ? "Aguarde…" : mode === "in" ? "Entrar" : "Cadastrar"}
                </Button>
              </form>
              <button
                type="button"
                className="text-sm text-muted hover:text-paper"
                onClick={() => {
                  setMode((m) => (m === "in" ? "up" : "in"));
                  setError(null);
                }}
              >
                {mode === "in" ? "Não tem conta? Cadastre-se" : "Já tem conta? Entrar"}
              </button>
            </>
          ) : (
            <p className="text-sm text-muted">O acesso está desativado neste momento.</p>
          )}
        </div>
      </div>
    </main>
  );
}
