import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PenLine, Search } from "lucide-react";
import { CoverImage, GenreChip, NovelRail } from "@/components/cover-card";
import { PageShell } from "@/components/header";
import { Button } from "@/components/ui/button";
import { getHomeData } from "@/lib/fn/catalog";
import { GENRES } from "@/lib/constants";
import { displayedAuthor } from "@/lib/types";
import { formatCount } from "@/lib/utils";

export const Route = createFileRoute("/")({
  loader: () => getHomeData(),
  component: Home,
});

function Home() {
  const initial = Route.useLoaderData();
  const { data = initial } = useQuery({
    queryKey: ["home"],
    queryFn: () => getHomeData(),
    initialData: initial,
  });
  const featured = data?.featured;
  const hasCatalog = Boolean(data?.popular?.length || data?.recent?.length);

  return (
    <PageShell className="max-w-6xl space-y-14 pt-6">
      <section className="grain relative overflow-hidden rounded-3xl border border-line bg-ink-2">
        <div className="seigaiha absolute inset-0 opacity-80" />
        <div className="relative grid gap-8 p-6 md:grid-cols-[1.1fr_0.9fr] md:p-10 lg:p-12">
          <div className="flex flex-col justify-center">
            <p className="text-xs tracking-[0.28em] text-seal uppercase">Light novels ilustradas</p>
            <h1 className="mt-3 font-display text-5xl leading-[0.95] font-semibold tracking-tight text-paper md:text-6xl lg:text-7xl">
              Onde as histórias ganham luz
            </h1>
            <p className="mt-5 max-w-lg text-base leading-relaxed text-paper/75">
              Publique sua light novel, escreva capítulos com ilustrações no meio da cena e leia obras de autores reais
              — cada título aqui nasceu de alguém que sentou para escrever.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild variant="paper" size="lg">
                <Link to="/criar">
                  <PenLine className="size-4" />
                  Criar Light Novel
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/explorar">
                  <Search className="size-4" />
                  Explorar obras
                </Link>
              </Button>
            </div>
          </div>
          {featured ? (
            <Link
              to="/obra/$slug"
              params={{ slug: featured.slug }}
              className="grid grid-cols-[140px_1fr] items-end gap-5 rounded-2xl bg-ink/40 p-4 md:grid-cols-[180px_1fr]"
            >
              <CoverImage src={featured.coverUrl} title={featured.title} className="rounded-xl" />
              <div className="pb-1">
                <p className="text-xs tracking-widest text-seal uppercase">Em destaque</p>
                <h2 className="mt-1 font-display text-3xl font-semibold tracking-tight">{featured.title}</h2>
                <p className="mt-1 text-sm text-muted">{displayedAuthor(featured)}</p>
                <p className="mt-3 line-clamp-4 text-sm leading-relaxed text-paper/75">{featured.synopsis}</p>
                <p className="mt-3 text-xs text-muted">
                  {featured.chapterCount} caps. · {formatCount(featured.likesCount)} curtidas
                </p>
              </div>
            </Link>
          ) : (
            <div className="flex flex-col justify-center rounded-2xl border border-dashed border-line bg-ink/40 p-6 md:p-8">
              <p className="text-xs tracking-[0.28em] text-seal uppercase">Catálogo em branco</p>
              <h2 className="mt-3 font-display text-3xl font-semibold tracking-tight">Ainda não há obras publicadas</h2>
              <p className="mt-3 text-sm leading-relaxed text-paper/75">
                O Lunova começa vazio de propósito. Quando alguém publicar uma light novel, ela aparece aqui.
              </p>
              <Button asChild variant="paper" className="mt-6 w-fit">
                <Link to="/criar">Escrever a primeira obra</Link>
              </Button>
            </div>
          )}
        </div>
      </section>

      <section className="space-y-3">
        <h2 className="font-display text-2xl font-semibold">Gêneros</h2>
        <div className="flex flex-wrap gap-2">
          {GENRES.map((g) => (
            <GenreChip key={g.slug} slug={g.slug} />
          ))}
        </div>
      </section>

      {hasCatalog ? (
        <>
          <NovelRail title="Obras populares" novels={data?.popular ?? []} href="/explorar" />
          <NovelRail title="Obras recentes" novels={data?.recent ?? []} href="/explorar" />
          <NovelRail title="Recomendadas" novels={data?.recommended ?? []} />
        </>
      ) : (
        <section className="rounded-2xl border border-dashed border-line px-6 py-14 text-center">
          <p className="font-display text-2xl font-semibold">Nenhuma light novel por aqui ainda</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted">
            Sem obras de exemplo. O catálogo só cresce com histórias reais — a sua pode ser a primeira.
          </p>
          <Button asChild className="mt-6">
            <Link to="/criar">
              <PenLine className="size-4" />
              Criar Light Novel
            </Link>
          </Button>
        </section>
      )}
    </PageShell>
  );
}
