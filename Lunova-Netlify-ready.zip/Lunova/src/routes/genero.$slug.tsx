import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PenLine } from "lucide-react";
import { CoverCard, GenreChip } from "@/components/cover-card";
import { PageShell } from "@/components/header";
import { Button } from "@/components/ui/button";
import { searchNovels } from "@/lib/fn/catalog";
import { GENRE_LABEL, GENRES } from "@/lib/constants";

export const Route = createFileRoute("/genero/$slug")({ component: Genero });

function Genero() {
  const { slug } = Route.useParams();
  const { data, isPending } = useQuery({
    queryKey: ["genre", slug],
    queryFn: () => searchNovels({ data: { q: "", genre: slug } }),
  });
  const label = GENRE_LABEL[slug] ?? slug;
  return (
    <PageShell className="space-y-8">
      <header className="space-y-3">
        <p className="text-xs tracking-[0.28em] text-seal uppercase">Gênero</p>
        <h1 className="font-display text-4xl font-semibold tracking-tight">{label}</h1>
        <div className="flex flex-wrap gap-2">
          {GENRES.map((g) => (
            <GenreChip key={g.slug} slug={g.slug} className={g.slug === slug ? "border-seal bg-seal/10" : undefined} />
          ))}
        </div>
      </header>
      {isPending ? (
        <p className="text-muted">Carregando…</p>
      ) : (data ?? []).length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line px-6 py-14 text-center">
          <p className="font-display text-2xl font-semibold">Ainda não há obras de {label.toLowerCase()}</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted">
            Quando um autor publicar neste gênero, a obra aparece aqui.
          </p>
          <Button asChild className="mt-6">
            <Link to="/criar">
              <PenLine className="size-4" />
              Escrever uma
            </Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {(data ?? []).map((n) => (
            <CoverCard key={n.id} novel={n} />
          ))}
        </div>
      )}
    </PageShell>
  );
}
