import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { CoverCard } from "@/components/cover-card";
import { PageShell } from "@/components/header";
import { Button } from "@/components/ui/button";
import { getPublicProfile } from "@/lib/fn/profile";
import { toggleFollow } from "@/lib/fn/social";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { formatCount } from "@/lib/utils";

export const Route = createFileRoute("/u/$username")({ component: ProfilePage });

function ProfilePage() {
  const { username } = Route.useParams();
  const qc = useQueryClient();
  const { user, isPending: authPending } = useCurrentUserState();
  const { data, isPending } = useQuery({
    queryKey: ["profile", username],
    queryFn: () => getPublicProfile({ data: { username } }),
  });

  const followMut = useMutation({
    mutationFn: () => toggleFollow({ data: { authorId: data!.profile.userId } }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["profile", username] }),
  });

  if (isPending) {
    return (
      <PageShell>
        <p className="text-muted">Carregando perfil…</p>
      </PageShell>
    );
  }
  if (!data) {
    return (
      <PageShell>
        <h1 className="font-display text-3xl">Autor não encontrado</h1>
      </PageShell>
    );
  }

  const { profile } = data;

  return (
    <PageShell className="space-y-12">
      <header className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex gap-4">
          <div className="grid size-20 place-items-center overflow-hidden rounded-full bg-ink-3 font-display text-3xl outline outline-1 outline-paper/10">
            {profile.avatarUrl ? (
              <img src={profile.avatarUrl} alt="" className="size-full object-cover" />
            ) : (
              profile.displayName.slice(0, 1)
            )}
          </div>
          <div>
            <h1 className="font-display text-4xl font-semibold tracking-tight">{profile.displayName}</h1>
            <p className="text-sm text-muted">@{profile.username}</p>
            <p className="mt-3 max-w-xl text-sm leading-relaxed text-paper/80">{profile.bio || "Este autor ainda não escreveu uma biografia."}</p>
            <p className="mt-3 text-sm text-muted">
              {formatCount(profile.followers)} seguidores · {profile.novelCount} obras · {formatCount(profile.following)}{" "}
              seguindo
            </p>
          </div>
        </div>
        {data.isSelf ? (
          <Button asChild variant="secondary">
            <Link to="/conta">Editar perfil</Link>
          </Button>
        ) : (
          <Button
            variant={data.isFollowing ? "secondary" : "primary"}
            onClick={() => {
              if (authPending) return;
              if (!user) {
                toast("Entre para seguir autores.");
                return;
              }
              followMut.mutate();
            }}
          >
            {data.isFollowing ? "Seguindo" : "Seguir"}
          </Button>
        )}
      </header>

      <section className="space-y-4">
        <h2 className="font-display text-2xl font-semibold">Light novels publicadas</h2>
        {data.novels.length === 0 ? (
          <p className="text-muted">Nenhuma obra publicada.</p>
        ) : (
          <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {data.novels.map((n) => (
              <CoverCard key={n.id} novel={n} />
            ))}
          </div>
        )}
      </section>

      <section className="space-y-4">
        <h2 className="font-display text-2xl font-semibold">Obras favoritas</h2>
        {data.favorites.length === 0 ? (
          <p className="text-muted">Nenhum favorito público.</p>
        ) : (
          <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {data.favorites.map((n) => (
              <CoverCard key={n.id} novel={n} />
            ))}
          </div>
        )}
      </section>
    </PageShell>
  );
}
