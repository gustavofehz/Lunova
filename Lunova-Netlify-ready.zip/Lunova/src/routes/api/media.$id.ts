import { Buffer } from "node:buffer";
import { createFileRoute } from "@tanstack/react-router";
import { getSql } from "@/lib/db";

export const Route = createFileRoute("/api/media/$id")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const sql = await getSql();
        const rows = await sql.query<{ mime: string; data: string }>(
          `select mime, data from media where id = $1`,
          [params.id],
        );
        const row = rows[0];
        if (!row) return new Response("Not found", { status: 404 });
        const buf = Buffer.from(row.data, "base64");
        return new Response(buf, {
          headers: {
            "Content-Type": row.mime || "image/jpeg",
            "Cache-Control": "public, max-age=31536000, immutable",
          },
        });
      },
    },
  },
});
