import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { PenLine } from "lucide-react";
import { CoverCard, GenreChip } from "@/components/cover-card";
import { PageShell } from "@/components/header";
import { Button } from "@/components/ui/button";
import { getExplore } from "@/lib/fn/catalog";
import { GENRES } from "@/lib/constants";

export const Route = createFileRoute("/explorar")({ component: Explorar });

function Explorar() {
  const { data, isPending } = useQuery({ queryKey: ["explore"], queryFn: () => getExplore() });
  return (
    <PageShell className="space-y-8">
      <header className="space-y-3">
        <p className="text-xs tracking-[0.28em] text-seal uppercase">Catálogo</p>
        <h1 className="font-display text-4xl font-semibold tracking-tight">Explorar</h1>
        <div className="flex flex-wrap gap-2">
          {GENRES.map((g) => (
            <GenreChip key={g.slug} slug={g.slug} />
          ))}
        </div>
      </header>
      {isPending ? (
        <p className="text-muted">Carregando obras…</p>
      ) : (data ?? []).length === 0 ? (
        <div className="rounded-2xl border border-dashed border-line px-6 py-16 text-center">
          <p className="font-display text-2xl font-semibold">O catálogo ainda está vazio</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted">
            Não há obras de exemplo. Publique a sua light novel para que leitores a encontrem aqui.
          </p>
          <Button asChild className="mt-6">
            <Link to="/criar">
              <PenLine className="size-4" />
              Criar Light Novel
            </Link>
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {(data ?? []).map((n) => (
            <CoverCard key={n.id} novel={n} />
          ))}
        </div>
      )}
    </PageShell>
  );
}
