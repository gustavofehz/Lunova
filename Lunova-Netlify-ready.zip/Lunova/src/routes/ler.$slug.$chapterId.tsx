import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { ChapterReader } from "@/components/chapter-reader";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/input";
import { getChapterRead } from "@/lib/fn/catalog";
import { addComment } from "@/lib/fn/social";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { relativeTime } from "@/lib/utils";

export const Route = createFileRoute("/ler/$slug/$chapterId")({ component: LerPage });

function LerPage() {
  const { slug, chapterId } = Route.useParams();
  const qc = useQueryClient();
  const { user, isPending: authPending } = useCurrentUserState();
  const { data, isPending } = useQuery({
    queryKey: ["read", slug, chapterId],
    queryFn: () => getChapterRead({ data: { slug, chapterId } }),
  });
  const [body, setBody] = useState("");

  const commentMut = useMutation({
    mutationFn: () => addComment({ data: { chapterId, body } }),
    onSuccess: () => {
      setBody("");
      void qc.invalidateQueries({ queryKey: ["read", slug, chapterId] });
    },
    onError: (e) => toast(e instanceof Error ? e.message : "Não foi possível comentar."),
  });

  if (isPending) {
    return (
      <div className="grid min-h-screen place-items-center bg-ink text-muted">
        Abrindo o capítulo…
      </div>
    );
  }
  if (!data) {
    return (
      <div className="grid min-h-screen place-items-center bg-ink text-paper">
        <div className="text-center">
          <p className="font-display text-2xl">Capítulo indisponível</p>
          <Link to="/" className="mt-3 inline-block text-sm text-muted hover:text-paper">
            Voltar
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div>
      <ChapterReader novel={data.novel} chapter={data.chapter} prev={data.prev} next={data.next} />
      <section className="border-t border-line bg-ink px-5 py-12 text-paper">
        <div className="mx-auto max-w-2xl">
          <h2 className="font-display text-2xl font-semibold">Comentários</h2>
          {!authPending && user ? (
            <form
              className="mt-4 space-y-3"
              onSubmit={(e) => {
                e.preventDefault();
                commentMut.mutate();
              }}
            >
              <Textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="O que este capítulo deixou em você?"
                maxLength={1200}
              />
              <Button type="submit" disabled={commentMut.isPending || !body.trim()}>
                Publicar comentário
              </Button>
            </form>
          ) : (
            <p className="mt-3 text-sm text-muted">
              <Link to="/login" className="text-paper underline">
                Entre
              </Link>{" "}
              para comentar.
            </p>
          )}
          <ul className="mt-8 space-y-5">
            {data.comments.length === 0 ? (
              <li className="text-sm text-muted">Seja o primeiro a deixar um comentário.</li>
            ) : (
              data.comments.map((c) => (
                <li key={c.id} className="rounded-xl border border-line bg-ink-2 p-4">
                  <div className="flex items-baseline justify-between gap-3">
                    <Link to="/u/$username" params={{ username: c.username }} className="text-sm font-medium">
                      {c.displayName}
                    </Link>
                    <span className="text-xs text-muted">{relativeTime(c.createdAt)}</span>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-paper/85">{c.body}</p>
                </li>
              ))
            )}
          </ul>
        </div>
      </section>
    </div>
  );
}
