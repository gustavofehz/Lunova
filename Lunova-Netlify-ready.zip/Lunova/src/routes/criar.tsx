import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUser, useCurrentUserState } from "@/lib/auth/use-current-user";
import { PageShell } from "@/components/header";
import { NovelForm } from "@/components/novel-form";
import { createNovel } from "@/lib/fn/studio";

export const Route = createFileRoute("/criar")({ component: CriarPage });

function CriarPage() {
  const { user, isPending } = useCurrentUserState();
  const me = useCurrentUser();
  const navigate = useNavigate();

  if (isPending) {
    return (
      <PageShell>
        <div className="h-10 w-48 animate-pulse rounded-lg bg-ink-3" />
      </PageShell>
    );
  }
  if (!user) return <RedirectToSignIn />;

  return (
    <PageShell className="max-w-4xl space-y-8">
      <header>
        <p className="text-xs tracking-[0.28em] text-seal uppercase">Estúdio</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">Nova light novel</h1>
        <p className="mt-2 max-w-xl text-muted">
          Defina a identidade da obra. Em seguida você entra no editor para escrever o primeiro capítulo e inserir
          ilustrações no meio da cena.
        </p>
      </header>
      <NovelForm
        initial={{
          title: "",
          synopsis: "",
          penName: me?.displayName ?? "",
          genres: [],
          tags: [],
          ageRating: "livre",
          status: "ongoing",
          coverUrl: null,
        }}
        submitLabel="Criar e escrever"
        onSubmit={async (values) => {
          const res = await createNovel({ data: values });
          await navigate({
            to: "/estudio/$novelId/capitulo/$chapterId",
            params: { novelId: res.id, chapterId: res.chapterId },
          });
        }}
      />
    </PageShell>
  );
}
