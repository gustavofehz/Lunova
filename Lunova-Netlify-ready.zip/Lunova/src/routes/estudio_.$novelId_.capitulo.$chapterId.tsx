import { useQuery } from "@tanstack/react-query";
import { createFileRoute, Link } from "@tanstack/react-router";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { ChapterEditor } from "@/components/chapter-editor";
import { getStudioChapter } from "@/lib/fn/studio";

export const Route = createFileRoute("/estudio_/$novelId_/capitulo/$chapterId")({
  component: ChapterEditPage,
});

function ChapterEditPage() {
  const { novelId, chapterId } = Route.useParams();
  const { user, isPending: authPending } = useCurrentUserState();
  const { data, isPending } = useQuery({
    queryKey: ["studio-chapter", novelId, chapterId],
    queryFn: () => getStudioChapter({ data: { novelId, chapterId } }),
    enabled: !!user,
  });

  if (authPending) {
    return <div className="grid min-h-screen place-items-center bg-ink text-muted">Carregando sessão…</div>;
  }
  if (!user) return <RedirectToSignIn />;
  if (isPending) {
    return <div className="grid min-h-screen place-items-center bg-ink text-muted">Abrindo o editor…</div>;
  }
  if (!data) {
    return (
      <div className="grid min-h-screen place-items-center bg-ink text-paper">
        <div className="text-center">
          <p className="font-display text-2xl">Capítulo não encontrado</p>
          <Link to="/estudio/$novelId" params={{ novelId }} className="mt-3 inline-block text-sm text-muted">
            Voltar
          </Link>
        </div>
      </div>
    );
  }

  return (
    <ChapterEditor
      novelId={novelId}
      chapterId={chapterId}
      novelTitle={data.novel.title}
      initialTitle={data.chapter.title}
      initialContent={data.chapter.content}
      initialStatus={data.chapter.status}
    />
  );
}
