import { useQuery } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { CoverCard } from "@/components/cover-card";
import { PageShell } from "@/components/header";
import { searchNovels } from "@/lib/fn/catalog";

export const Route = createFileRoute("/buscar")({
  validateSearch: (s: Record<string, unknown>) => ({ q: String(s.q ?? "") }),
  component: Buscar,
});

function Buscar() {
  const { q } = Route.useSearch();
  const { data, isPending } = useQuery({
    queryKey: ["search", q],
    queryFn: () => searchNovels({ data: { q } }),
  });
  return (
    <PageShell className="space-y-8">
      <header>
        <p className="text-xs tracking-[0.28em] text-seal uppercase">Busca</p>
        <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">
          {q ? `Resultados para “${q}”` : "Buscar obras"}
        </h1>
      </header>
      {isPending ? (
        <p className="text-muted">Procurando nas estantes…</p>
      ) : (data ?? []).length === 0 ? (
        <p className="text-muted">Nenhuma obra encontrada. Tente outro título, autor ou trecho da sinopse.</p>
      ) : (
        <div className="grid grid-cols-2 gap-5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {(data ?? []).map((n) => (
            <CoverCard key={n.id} novel={n} />
          ))}
        </div>
      )}
    </PageShell>
  );
}
