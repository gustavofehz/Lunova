import { useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { PenLine } from "lucide-react";
import { toast } from "sonner";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { CoverImage } from "@/components/cover-card";
import { PageShell } from "@/components/header";
import { Button } from "@/components/ui/button";
import { createChapter, getMyStudio } from "@/lib/fn/studio";
import { STATUS_LABEL } from "@/lib/constants";
import { formatCount } from "@/lib/utils";

export const Route = createFileRoute("/estudio")({ component: EstudioPage });

function EstudioPage() {
  const { user, isPending: authPending } = useCurrentUserState();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { data, isPending } = useQuery({
    queryKey: ["studio"],
    queryFn: () => getMyStudio(),
    enabled: !!user,
  });

  async function writeNovel(novelId: string, latestChapterId: string | null) {
    try {
      if (latestChapterId) {
        await navigate({
          to: "/estudio/$novelId/capitulo/$chapterId",
          params: { novelId, chapterId: latestChapterId },
        });
        return;
      }
      const res = await createChapter({ data: { novelId } });
      await qc.invalidateQueries({ queryKey: ["studio"] });
      await navigate({
        to: "/estudio/$novelId/capitulo/$chapterId",
        params: { novelId, chapterId: res.id },
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Não foi possível abrir o editor.");
    }
  }

  if (authPending) {
    return (
      <PageShell>
        <div className="h-10 w-40 animate-pulse rounded-lg bg-ink-3" />
      </PageShell>
    );
  }
  if (!user) return <RedirectToSignIn />;

  return (
    <PageShell className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs tracking-[0.28em] text-seal uppercase">Painel do autor</p>
          <h1 className="mt-2 font-display text-4xl font-semibold tracking-tight">Estúdio</h1>
          <p className="mt-2 max-w-xl text-sm text-muted">
            Suas light novels. Abra o editor para escrever capítulos e inserir ilustrações.
          </p>
        </div>
        <Button asChild>
          <Link to="/criar">
            <PenLine className="size-4" />
            Nova obra
          </Link>
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
        <Stat label="Obras" value={String(data?.novels.length ?? 0)} />
        <Stat label="Curtidas" value={formatCount(data?.likes ?? 0)} />
        <Stat label="Leitores" value={formatCount(data?.readers ?? 0)} />
      </div>
      {isPending ? (
        <p className="text-muted">Carregando suas obras…</p>
      ) : !data?.novels.length ? (
        <div className="rounded-2xl border border-dashed border-line px-6 py-16 text-center">
          <p className="font-display text-2xl">Sua estante ainda está em branco.</p>
          <p className="mt-2 text-sm text-muted">Crie a primeira light novel e abra o editor de capítulos.</p>
          <Button asChild className="mt-6">
            <Link to="/criar">Começar a escrever</Link>
          </Button>
        </div>
      ) : (
        <ul className="space-y-3">
          {data.novels.map((n) => (
            <li
              key={n.id}
              className="flex flex-col gap-3 rounded-2xl border border-line bg-ink-2 p-3 sm:flex-row sm:items-center"
            >
              <Link
                to="/estudio/$novelId"
                params={{ novelId: n.id }}
                className="flex min-w-0 flex-1 gap-4"
              >
                <CoverImage src={n.coverUrl} title={n.title} fixed className="h-28 w-20 shrink-0 rounded-lg" />
                <div className="min-w-0 py-1">
                  <h2 className="truncate font-display text-xl font-semibold">{n.title}</h2>
                  <p className="mt-1 text-sm text-muted">
                    {n.published ? "Publicada" : "Rascunho"} · {STATUS_LABEL[n.status]} · {n.totalChapters}{" "}
                    {n.totalChapters === 1 ? "cap." : "caps."} · {formatCount(n.likesCount)} curtidas
                  </p>
                </div>
              </Link>
              <div className="flex shrink-0 gap-2 sm:flex-col">
                <Button
                  type="button"
                  className="flex-1 sm:flex-none"
                  onClick={() => void writeNovel(n.id, n.latestChapterId)}
                >
                  <PenLine className="size-4" />
                  Escrever
                </Button>
                <Button asChild variant="outline" className="flex-1 sm:flex-none">
                  <Link to="/estudio/$novelId" params={{ novelId: n.id }}>
                    Capítulos
                  </Link>
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </PageShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-line bg-ink-2 px-4 py-5">
      <p className="text-xs tracking-widest text-muted uppercase">{label}</p>
      <p className="mt-1 font-display text-3xl font-semibold tabular-nums">{value}</p>
    </div>
  );
}
