export const APP_NAME = "Lunova";
export const APP_TAGLINE = "Onde as histórias ganham luz";

export const GENRES = [
  { slug: "romance", label: "Romance" },
  { slug: "fantasia", label: "Fantasia" },
  { slug: "acao", label: "Ação" },
  { slug: "ficcao-cientifica", label: "Ficção Científica" },
  { slug: "terror", label: "Terror" },
  { slug: "comedia", label: "Comédia" },
  { slug: "drama", label: "Drama" },
  { slug: "misterio", label: "Mistério" },
  { slug: "aventura", label: "Aventura" },
  { slug: "slice-of-life", label: "Slice of Life" },
  { slug: "sobrenatural", label: "Sobrenatural" },
  { slug: "historico", label: "Histórico" },
] as const;

export type GenreSlug = (typeof GENRES)[number]["slug"];

export const GENRE_LABEL: Record<string, string> = Object.fromEntries(
  GENRES.map((g) => [g.slug, g.label]),
);

export const AGE_RATINGS = [
  { value: "livre", label: "Livre" },
  { value: "12", label: "12+" },
  { value: "14", label: "14+" },
  { value: "16", label: "16+" },
  { value: "18", label: "18+" },
] as const;

export const AGE_RATING_LABEL: Record<string, string> = Object.fromEntries(
  AGE_RATINGS.map((r) => [r.value, r.label]),
);

export const NOVEL_STATUSES = [
  { value: "ongoing", label: "Em andamento" },
  { value: "completed", label: "Concluída" },
  { value: "paused", label: "Pausada" },
] as const;

export const STATUS_LABEL: Record<string, string> = Object.fromEntries(
  NOVEL_STATUSES.map((s) => [s.value, s.label]),
);

export const SHELVES = [
  { value: "reading", label: "Lendo" },
  { value: "want", label: "Quero ler" },
  { value: "completed", label: "Concluídas" },
] as const;

export const SHELF_LABEL: Record<string, string> = Object.fromEntries(
  SHELVES.map((s) => [s.value, s.label]),
);

export const ALLOWED_IMAGE_MIMES = [
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
] as const;

export const MAX_IMAGE_BYTES = 1_400_000;
