import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { NOVEL_SELECT, mapChapterDetail, mapChapterMeta, mapNovel, type NovelRow } from "@/lib/server/map";
import { optionalAuthMiddleware } from "@/lib/optional-auth";
import type { ChapterDetail, CommentItem } from "@/lib/types";

export const getHomeData = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const popular = await sql.query<NovelRow>(
    `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
     where n.published = true order by n.likes_count desc, n.created_at desc limit 10`,
  );
  const recent = await sql.query<NovelRow>(
    `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
     where n.published = true order by n.created_at desc limit 10`,
  );
  const featured = await sql.query<NovelRow>(
    `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
     where n.published = true and n.featured = true limit 1`,
  );
  const recommended = await sql.query<NovelRow>(
    `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
     where n.published = true
     order by n.likes_count desc, n.created_at desc limit 16`,
  );
  const featuredMapped = featured[0] ? mapNovel(featured[0]) : popular[0] ? mapNovel(popular[0]) : null;
  const rec = recommended
    .map(mapNovel)
    .filter((n) => n.id !== featuredMapped?.id)
    .slice(0, 8);
  return {
    featured: featuredMapped,
    popular: popular.map(mapNovel),
    recent: recent.map(mapNovel),
    recommended: rec,
  };
});

export const searchNovels = createServerFn({ method: "GET" })
  .validator((data: { q: string; genre?: string }) => data)
  .handler(async ({ data }) => {
    const sql = await getSql();
    const q = data.q.trim();
    const genre = data.genre?.trim();
    let rows: NovelRow[];
    if (q && genre) {
      const like = `%${q.toLowerCase()}%`;
      rows = await sql.query<NovelRow>(
        `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
         where n.published = true
           and n.genres @> $1::jsonb
           and (lower(n.title) like $2 or lower(p.display_name) like $2 or lower(n.pen_name) like $2 or lower(n.synopsis) like $2)
         order by n.likes_count desc limit 40`,
        [JSON.stringify([genre]), like],
      );
    } else if (genre) {
      rows = await sql.query<NovelRow>(
        `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
         where n.published = true and n.genres @> $1::jsonb
         order by n.likes_count desc, n.created_at desc limit 40`,
        [JSON.stringify([genre])],
      );
    } else if (q) {
      const like = `%${q.toLowerCase()}%`;
      rows = await sql.query<NovelRow>(
        `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
         where n.published = true
           and (lower(n.title) like $1 or lower(p.display_name) like $1 or lower(n.pen_name) like $1 or lower(n.synopsis) like $1)
         order by n.likes_count desc limit 40`,
        [like],
      );
    } else {
      rows = await sql.query<NovelRow>(
        `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
         where n.published = true order by n.created_at desc limit 24`,
      );
    }
    return rows.map(mapNovel);
  });

export const getNovelBySlug = createServerFn({ method: "GET" })
  .middleware([optionalAuthMiddleware])
  .validator((data: { slug: string }) => data)
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    const rows = await sql.query<NovelRow>(
      `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
       where n.slug = $1 limit 1`,
      [data.slug],
    );
    if (!rows[0]) return null;
    const novel = mapNovel(rows[0]);
    if (!novel.published && context.userId !== novel.authorId) return null;

    const chapters = await sql.query<{
      id: string;
      novel_id: string;
      title: string;
      sort_order: number;
      status: string;
      word_count: number;
      published_at: string | null;
      updated_at: string;
    }>(
      `select id, novel_id, title, sort_order, status, word_count, published_at, updated_at
       from chapters where novel_id = $1
       order by sort_order asc`,
      [novel.id],
    );

    const visible = chapters
      .filter((c) => c.status === "published" || context.userId === novel.authorId)
      .map(mapChapterMeta);

    let liked = false;
    let myRating: number | null = null;
    let shelf: string | null = null;
    let isFavorite = false;
    let following = false;
    const readerRows = await sql.query<{ n: number }>(
      `select count(*)::int as n from reading_progress where novel_id = $1`,
      [novel.id],
    );
    const readers = readerRows[0]?.n ?? 0;

    if (context.userId) {
      const like = await sql.query<{ n: number }>(
        `select 1 as n from novel_likes where user_id = $1 and novel_id = $2`,
        [context.userId, novel.id],
      );
      liked = like.length > 0;
      const rating = await sql.query<{ stars: number }>(
        `select stars from ratings where user_id = $1 and novel_id = $2`,
        [context.userId, novel.id],
      );
      myRating = rating[0]?.stars ?? null;
      const lib = await sql.query<{ shelf: string; is_favorite: boolean }>(
        `select shelf, is_favorite from library_items where user_id = $1 and novel_id = $2`,
        [context.userId, novel.id],
      );
      if (lib[0]) {
        shelf = lib[0].shelf;
        isFavorite = Boolean(lib[0].is_favorite);
      }
      const fol = await sql.query<{ n: number }>(
        `select 1 as n from follows where follower_id = $1 and author_id = $2`,
        [context.userId, novel.authorId],
      );
      following = fol.length > 0;
    }

    const followerRows = await sql.query<{ n: number }>(
      `select count(*)::int as n from follows where author_id = $1`,
      [novel.authorId],
    );

    return {
      novel,
      chapters: visible,
      liked,
      myRating,
      shelf,
      isFavorite,
      following,
      readers,
      followers: followerRows[0]?.n ?? 0,
    };
  });

export const getChapterRead = createServerFn({ method: "GET" })
  .middleware([optionalAuthMiddleware])
  .validator((data: { slug: string; chapterId: string }) => data)
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    const rows = await sql.query<NovelRow>(
      `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
       where n.slug = $1 limit 1`,
      [data.slug],
    );
    if (!rows[0]) return null;
    const novel = mapNovel(rows[0]);
    const chapters = await sql.query<{
      id: string;
      novel_id: string;
      title: string;
      sort_order: number;
      status: string;
      word_count: number;
      published_at: string | null;
      updated_at: string;
      content: unknown;
    }>(
      `select id, novel_id, title, sort_order, status, word_count, published_at, updated_at, content
       from chapters where novel_id = $1 order by sort_order asc`,
      [novel.id],
    );
    const current = chapters.find((c) => c.id === data.chapterId);
    if (!current) return null;
    if (current.status !== "published" && context.userId !== novel.authorId) return null;

    const published = chapters.filter((c) => c.status === "published" || context.userId === novel.authorId);
    const idx = published.findIndex((c) => c.id === current.id);
    const prev = idx > 0 ? mapChapterMeta(published[idx - 1]) : null;
    const next = idx >= 0 && idx < published.length - 1 ? mapChapterMeta(published[idx + 1]) : null;

    const comments = await sql.query<{
      id: string;
      user_id: string;
      display_name: string;
      username: string;
      avatar_url: string | null;
      body: string;
      created_at: string;
    }>(
      `select c.id, c.user_id, coalesce(p.display_name, 'Leitor') as display_name,
              coalesce(p.username, 'leitor') as username, p.avatar_url, c.body, c.created_at
       from comments c
       left join profiles p on p.user_id = c.user_id
       where c.chapter_id = $1
       order by c.created_at desc
       limit 80`,
      [current.id],
    );

    if (context.userId) {
      await sql.query(
        `insert into reading_progress (user_id, novel_id, chapter_id, updated_at)
         values ($1, $2, $3, now())
         on conflict (user_id, novel_id) do update set chapter_id = excluded.chapter_id, updated_at = now()`,
        [context.userId, novel.id, current.id],
      );
    }

    return {
      novel,
      chapter: mapChapterDetail(current) as ChapterDetail,
      prev,
      next,
      chapters: published.map(mapChapterMeta),
      comments: comments.map(
        (c): CommentItem => ({
          id: c.id,
          userId: c.user_id,
          displayName: c.display_name,
          username: c.username,
          avatarUrl: c.avatar_url,
          body: c.body,
          createdAt: String(c.created_at),
        }),
      ),
    };
  });

export const getExplore = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql.query<NovelRow>(
    `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
     where n.published = true order by n.likes_count desc, n.created_at desc limit 48`,
  );
  return rows.map(mapNovel);
});
