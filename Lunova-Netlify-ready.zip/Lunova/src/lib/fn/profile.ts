import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { optionalAuthMiddleware } from "@/lib/optional-auth";
import { ensureProfile } from "@/lib/server/profile";
import { NOVEL_SELECT, mapNovel, type NovelRow } from "@/lib/server/map";
import { slugify } from "@/lib/utils";
import type { ProfilePublic } from "@/lib/types";

export const getMe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql.query<{
      user_id: string;
      username: string;
      display_name: string;
      bio: string;
      avatar_url: string | null;
      created_at: string;
    }>(`select user_id, username, display_name, bio, avatar_url, created_at from profiles where user_id = $1`, [
      context.userId,
    ]);
    return rows[0] ?? null;
  });

export const updateMe = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { displayName: string; bio: string; username: string; avatarUrl: string | null }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const displayName = data.displayName.trim().slice(0, 80) || "Autor";
    const bio = data.bio.trim().slice(0, 600);
    let username = slugify(data.username || displayName);
    const clash = await sql.query<{ user_id: string }>(
      `select user_id from profiles where username = $1 and user_id <> $2`,
      [username, context.userId],
    );
    if (clash[0]) username = `${username}-${Math.floor(1000 + Math.random() * 9000)}`;
    await sql.query(
      `update profiles set display_name = $1, bio = $2, username = $3, avatar_url = $4 where user_id = $5`,
      [displayName, bio, username, data.avatarUrl, context.userId],
    );
    return { username };
  });

export const getPublicProfile = createServerFn({ method: "GET" })
  .middleware([optionalAuthMiddleware])
  .validator((data: { username: string }) => data)
  .handler(async ({ data, context }) => {
    const sql = await getSql();
    const rows = await sql.query<{
      user_id: string;
      username: string;
      display_name: string;
      bio: string;
      avatar_url: string | null;
      created_at: string;
    }>(`select user_id, username, display_name, bio, avatar_url, created_at from profiles where username = $1`, [
      data.username,
    ]);
    if (!rows[0]) return null;
    const p = rows[0];
    const novels = await sql.query<NovelRow>(
      `select ${NOVEL_SELECT} from novels n join profiles pr on pr.user_id = n.author_id
       where n.author_id = $1 and n.published = true
       order by n.updated_at desc`,
      [p.user_id],
    );
    const favs = await sql.query<NovelRow>(
      `select ${NOVEL_SELECT} from library_items li
       join novels n on n.id = li.novel_id
       join profiles pr on pr.user_id = n.author_id
       where li.user_id = $1 and li.is_favorite = true and n.published = true
       order by li.created_at desc limit 12`,
      [p.user_id],
    );
    const followers = await sql.query<{ n: number }>(
      `select count(*)::int as n from follows where author_id = $1`,
      [p.user_id],
    );
    const followingN = await sql.query<{ n: number }>(
      `select count(*)::int as n from follows where follower_id = $1`,
      [p.user_id],
    );
    let following = false;
    if (context.userId) {
      const f = await sql.query<{ n: number }>(
        `select 1 as n from follows where follower_id = $1 and author_id = $2`,
        [context.userId, p.user_id],
      );
      following = f.length > 0;
    }
    const profile: ProfilePublic = {
      userId: p.user_id,
      username: p.username,
      displayName: p.display_name,
      bio: p.bio,
      avatarUrl: p.avatar_url,
      followers: followers[0]?.n ?? 0,
      following: followingN[0]?.n ?? 0,
      novelCount: novels.length,
      createdAt: String(p.created_at),
    };
    return {
      profile,
      novels: novels.map(mapNovel),
      favorites: favs.map(mapNovel),
      isFollowing: following,
      isSelf: context.userId === p.user_id,
    };
  });
