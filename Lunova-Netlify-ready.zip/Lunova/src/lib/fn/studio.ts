import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { ensureProfile, uniqueSlug } from "@/lib/server/profile";
import { NOVEL_SELECT, mapChapterDetail, mapChapterMeta, mapNovel, type NovelRow } from "@/lib/server/map";
import { emptyContent, parseContent, type ChapterContent, type NovelStatus } from "@/lib/types";
import { wordCountOf } from "@/lib/chapter-content";
import { GENRE_LABEL, AGE_RATING_LABEL, STATUS_LABEL } from "@/lib/constants";

function assertGenre(list: string[]): string[] {
  return [...new Set(list.filter((g) => g in GENRE_LABEL))].slice(0, 5);
}

type StudioNovelRow = NovelRow & {
  latest_chapter_id: string | null;
  total_chapters: number;
};

export const getMyStudio = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql.query<StudioNovelRow>(
      `select ${NOVEL_SELECT},
         (select c.id from chapters c where c.novel_id = n.id order by c.updated_at desc limit 1) as latest_chapter_id,
         (select count(*)::int from chapters c where c.novel_id = n.id) as total_chapters
       from novels n join profiles p on p.user_id = n.author_id
       where n.author_id = $1
       order by n.updated_at desc`,
      [context.userId],
    );
    const novels = rows.map((row) => ({
      ...mapNovel(row),
      latestChapterId: row.latest_chapter_id,
      totalChapters: Number(row.total_chapters) || 0,
    }));
    const stats = await sql.query<{ likes: number; readers: number }>(
      `select
         coalesce((select sum(likes_count)::int from novels where author_id = $1), 0) as likes,
         coalesce((select count(*)::int from reading_progress rp
                   join novels n on n.id = rp.novel_id where n.author_id = $1), 0) as readers`,
      [context.userId],
    );
    return {
      novels,
      likes: stats[0]?.likes ?? 0,
      readers: stats[0]?.readers ?? 0,
    };
  });

export const createNovel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: {
      title: string;
      synopsis: string;
      penName: string;
      genres: string[];
      tags: string[];
      ageRating: string;
      status: NovelStatus;
      coverUrl: string | null;
    }) => data,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const title = data.title.trim().slice(0, 120);
    if (!title) throw new Error("Dê um título à obra.");
    const slug = await uniqueSlug(sql, title);
    const id = crypto.randomUUID();
    const genres = assertGenre(data.genres);
    const tags = data.tags.map((t) => t.trim()).filter(Boolean).slice(0, 12);
    const age = data.ageRating in AGE_RATING_LABEL ? data.ageRating : "livre";
    const status = data.status in STATUS_LABEL ? data.status : "ongoing";
    await sql.query(
      `insert into novels (
         id, slug, author_id, pen_name, title, synopsis, cover_url,
         genres, tags, age_rating, status, published
       ) values ($1,$2,$3,$4,$5,$6,$7,$8::jsonb,$9::jsonb,$10,$11,false)`,
      [
        id,
        slug,
        context.userId,
        data.penName.trim().slice(0, 80),
        title,
        data.synopsis.trim().slice(0, 2000),
        data.coverUrl,
        JSON.stringify(genres),
        JSON.stringify(tags),
        age,
        status,
      ],
    );
    const chapterId = crypto.randomUUID();
    const content = emptyContent();
    await sql.query(
      `insert into chapters (id, novel_id, title, sort_order, content, status, word_count)
       values ($1,$2,$3,$4,$5::jsonb,'draft',0)`,
      [chapterId, id, "Capítulo 1", 1, JSON.stringify(content)],
    );
    return { id, slug, chapterId };
  });

export const updateNovel = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: {
      id: string;
      title: string;
      synopsis: string;
      penName: string;
      genres: string[];
      tags: string[];
      ageRating: string;
      status: NovelStatus;
      coverUrl: string | null;
      published: boolean;
    }) => data,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const title = data.title.trim().slice(0, 120);
    if (!title) throw new Error("Dê um título à obra.");
    const res = await sql.query(
      `update novels set
         title = $1, synopsis = $2, pen_name = $3, genres = $4::jsonb, tags = $5::jsonb,
         age_rating = $6, status = $7, cover_url = $8, published = $9, updated_at = now()
       where id = $10 and author_id = $11`,
      [
        title,
        data.synopsis.trim().slice(0, 2000),
        data.penName.trim().slice(0, 80),
        JSON.stringify(assertGenre(data.genres)),
        JSON.stringify(data.tags.map((t) => t.trim()).filter(Boolean).slice(0, 12)),
        data.ageRating in AGE_RATING_LABEL ? data.ageRating : "livre",
        data.status in STATUS_LABEL ? data.status : "ongoing",
        data.coverUrl,
        data.published,
        data.id,
        context.userId,
      ],
    );
    void res;
    return { ok: true };
  });

export const getStudioNovel = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { id: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql.query<NovelRow>(
      `select ${NOVEL_SELECT} from novels n join profiles p on p.user_id = n.author_id
       where n.id = $1 and n.author_id = $2`,
      [data.id, context.userId],
    );
    if (!rows[0]) return null;
    const chapters = await sql.query<{
      id: string;
      novel_id: string;
      title: string;
      sort_order: number;
      status: string;
      word_count: number;
      published_at: string | null;
      updated_at: string;
    }>(
      `select id, novel_id, title, sort_order, status, word_count, published_at, updated_at
       from chapters where novel_id = $1 order by sort_order asc`,
      [data.id],
    );
    const readers = await sql.query<{ n: number }>(
      `select count(*)::int as n from reading_progress where novel_id = $1`,
      [data.id],
    );
    return {
      novel: mapNovel(rows[0]),
      chapters: chapters.map(mapChapterMeta),
      readers: readers[0]?.n ?? 0,
    };
  });

export const createChapter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { novelId: string; title?: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const owned = await sql.query<{ id: string }>(
      `select id from novels where id = $1 and author_id = $2`,
      [data.novelId, context.userId],
    );
    if (!owned[0]) throw new Error("Obra não encontrada.");
    const max = await sql.query<{ m: number }>(
      `select coalesce(max(sort_order), 0)::int as m from chapters where novel_id = $1`,
      [data.novelId],
    );
    const id = crypto.randomUUID();
    const order = (max[0]?.m ?? 0) + 1;
    const title = (data.title?.trim() || `Capítulo ${order}`).slice(0, 160);
    const content = emptyContent();
    await sql.query(
      `insert into chapters (id, novel_id, title, sort_order, content, status, word_count)
       values ($1,$2,$3,$4,$5::jsonb,'draft',0)`,
      [id, data.novelId, title, order, JSON.stringify(content)],
    );
    await sql.query(`update novels set updated_at = now() where id = $1`, [data.novelId]);
    return { id };
  });

export const getStudioChapter = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((data: { novelId: string; chapterId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const owned = await sql.query<{ id: string; title: string; slug: string }>(
      `select id, title, slug from novels where id = $1 and author_id = $2`,
      [data.novelId, context.userId],
    );
    if (!owned[0]) return null;
    const ch = await sql.query<{
      id: string;
      novel_id: string;
      title: string;
      sort_order: number;
      status: string;
      word_count: number;
      published_at: string | null;
      updated_at: string;
      content: unknown;
    }>(
      `select id, novel_id, title, sort_order, status, word_count, published_at, updated_at, content
       from chapters where id = $1 and novel_id = $2`,
      [data.chapterId, data.novelId],
    );
    if (!ch[0]) return null;
    return {
      novel: owned[0],
      chapter: mapChapterDetail(ch[0]),
    };
  });

export const saveChapter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: {
      novelId: string;
      chapterId: string;
      title: string;
      content: ChapterContent;
      publish?: boolean;
      draft?: boolean;
    }) => data,
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const owned = await sql.query<{ id: string }>(
      `select id from novels where id = $1 and author_id = $2`,
      [data.novelId, context.userId],
    );
    if (!owned[0]) throw new Error("Obra não encontrada.");
    const content = parseContent(data.content);
    const words = wordCountOf(content);
    const title = data.title.trim().slice(0, 160) || "Sem título";
    let statusSql = "";
    const params: unknown[] = [
      title,
      JSON.stringify(content),
      words,
      data.chapterId,
      data.novelId,
    ];
    if (data.publish) {
      statusSql = `, status = 'published', published_at = coalesce(published_at, now())`;
    } else if (data.draft) {
      statusSql = `, status = 'draft'`;
    }
    await sql.query(
      `update chapters set title = $1, content = $2::jsonb, word_count = $3, updated_at = now() ${statusSql}
       where id = $4 and novel_id = $5`,
      params,
    );
    if (data.publish) {
      await sql.query(`update novels set published = true, updated_at = now() where id = $1`, [data.novelId]);
    } else {
      await sql.query(`update novels set updated_at = now() where id = $1`, [data.novelId]);
    }
    const row = await sql.query<{ updated_at: string; status: string }>(
      `select updated_at, status from chapters where id = $1`,
      [data.chapterId],
    );
    return {
      updatedAt: String(row[0]?.updated_at ?? new Date().toISOString()),
      status: row[0]?.status ?? "draft",
      wordCount: words,
    };
  });

export const reorderChapters = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { novelId: string; orderedIds: string[] }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const owned = await sql.query<{ id: string }>(
      `select id from novels where id = $1 and author_id = $2`,
      [data.novelId, context.userId],
    );
    if (!owned[0]) throw new Error("Obra não encontrada.");
    let i = 1;
    for (const id of data.orderedIds) {
      await sql.query(
        `update chapters set sort_order = $1 where id = $2 and novel_id = $3`,
        [i, id, data.novelId],
      );
      i += 1;
    }
    return { ok: true };
  });

export const deleteChapter = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { novelId: string; chapterId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const owned = await sql.query<{ id: string }>(
      `select id from novels where id = $1 and author_id = $2`,
      [data.novelId, context.userId],
    );
    if (!owned[0]) throw new Error("Obra não encontrada.");
    await sql.query(`delete from chapters where id = $1 and novel_id = $2`, [data.chapterId, data.novelId]);
    return { ok: true };
  });
