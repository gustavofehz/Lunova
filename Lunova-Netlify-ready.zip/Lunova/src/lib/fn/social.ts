import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { ensureProfile } from "@/lib/server/profile";
import { NOVEL_SELECT, mapNovel, type NovelRow } from "@/lib/server/map";
import type { LibraryEntry, Shelf } from "@/lib/types";
import { SHELF_LABEL } from "@/lib/constants";

export const toggleLike = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { novelId: string }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const existing = await sql.query<{ n: number }>(
      `select 1 as n from novel_likes where user_id = $1 and novel_id = $2`,
      [context.userId, data.novelId],
    );
    if (existing[0]) {
      await sql.query(`delete from novel_likes where user_id = $1 and novel_id = $2`, [
        context.userId,
        data.novelId,
      ]);
      await sql.query(
        `update novels set likes_count = greatest(likes_count - 1, 0) where id = $1`,
        [data.novelId],
      );
      return { liked: false };
    }
    await sql.query(`insert into novel_likes (user_id, novel_id) values ($1,$2) on conflict do nothing`, [
      context.userId,
      data.novelId,
    ]);
    await sql.query(`update novels set likes_count = likes_count + 1 where id = $1`, [data.novelId]);
    return { liked: true };
  });

export const setRating = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { novelId: string; stars: number }) => data)
  .handler(async ({ context, data }) => {
    const stars = Math.min(5, Math.max(1, Math.round(data.stars)));
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    await sql.query(
      `insert into ratings (user_id, novel_id, stars) values ($1,$2,$3)
       on conflict (user_id, novel_id) do update set stars = excluded.stars`,
      [context.userId, data.novelId, stars],
    );
    return { stars };
  });

export const toggleFollow = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { authorId: string }) => data)
  .handler(async ({ context, data }) => {
    if (data.authorId === context.userId) return { following: false };
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const existing = await sql.query<{ n: number }>(
      `select 1 as n from follows where follower_id = $1 and author_id = $2`,
      [context.userId, data.authorId],
    );
    if (existing[0]) {
      await sql.query(`delete from follows where follower_id = $1 and author_id = $2`, [
        context.userId,
        data.authorId,
      ]);
      return { following: false };
    }
    await sql.query(
      `insert into follows (follower_id, author_id) values ($1,$2) on conflict do nothing`,
      [context.userId, data.authorId],
    );
    return { following: true };
  });

export const setLibrary = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { novelId: string; shelf?: Shelf | null; favorite?: boolean }) => data)
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const current = await sql.query<{ shelf: string; is_favorite: boolean }>(
      `select shelf, is_favorite from library_items where user_id = $1 and novel_id = $2`,
      [context.userId, data.novelId],
    );
    const shelf =
      data.shelf === undefined
        ? (current[0]?.shelf ?? "want")
        : data.shelf;
    const isFavorite =
      data.favorite === undefined ? Boolean(current[0]?.is_favorite) : data.favorite;
    if (!shelf && !isFavorite) {
      await sql.query(`delete from library_items where user_id = $1 and novel_id = $2`, [
        context.userId,
        data.novelId,
      ]);
      return { shelf: null, isFavorite: false };
    }
    const shelfValue = shelf && shelf in SHELF_LABEL ? shelf : current[0]?.shelf ?? "want";
    await sql.query(
      `insert into library_items (user_id, novel_id, shelf, is_favorite)
       values ($1,$2,$3,$4)
       on conflict (user_id, novel_id) do update set shelf = excluded.shelf, is_favorite = excluded.is_favorite`,
      [context.userId, data.novelId, shelfValue, isFavorite],
    );
    return { shelf: shelfValue, isFavorite };
  });

export const getLibrary = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const rows = await sql.query<NovelRow & { shelf: string; is_favorite: boolean }>(
      `select ${NOVEL_SELECT}, li.shelf, li.is_favorite
       from library_items li
       join novels n on n.id = li.novel_id
       join profiles p on p.user_id = n.author_id
       where li.user_id = $1
       order by li.created_at desc`,
      [context.userId],
    );
    return rows.map((r) => ({
      ...mapNovel(r),
      shelf: r.shelf as Shelf,
      isFavorite: Boolean(r.is_favorite),
    })) satisfies LibraryEntry[];
  });

export const addComment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { chapterId: string; body: string }) => data)
  .handler(async ({ context, data }) => {
    const body = data.body.trim().slice(0, 1200);
    if (!body) throw new Error("Escreva um comentário.");
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const id = crypto.randomUUID();
    await sql.query(
      `insert into comments (id, chapter_id, user_id, body) values ($1,$2,$3,$4)`,
      [id, data.chapterId, context.userId, body],
    );
    return { id };
  });
