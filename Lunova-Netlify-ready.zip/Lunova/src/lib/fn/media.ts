import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { ALLOWED_IMAGE_MIMES, MAX_IMAGE_BYTES } from "@/lib/constants";

export const uploadMedia = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { mime: string; data: string }) => data)
  .handler(async ({ context, data }) => {
    const mime = data.mime === "image/jpg" ? "image/jpeg" : data.mime;
    if (!(ALLOWED_IMAGE_MIMES as readonly string[]).includes(mime) && mime !== "image/jpeg") {
      throw new Error("Formato não suportado. Use JPG, PNG ou WEBP.");
    }
    const b64 = data.data.replace(/\s/g, "");
    const approxBytes = Math.floor((b64.length * 3) / 4);
    if (approxBytes > MAX_IMAGE_BYTES) {
      throw new Error("Imagem grande demais. Reduza a resolução e tente de novo.");
    }
    const id = crypto.randomUUID();
    const sql = await getSql();
    await sql.query(`insert into media (id, user_id, mime, data) values ($1,$2,$3,$4)`, [
      id,
      context.userId,
      mime,
      b64,
    ]);
    return { id, url: `/api/media/${id}` };
  });
