import type { Sql } from "@/lib/db";
import { slugify } from "@/lib/utils";

export async function ensureProfile(
  sql: Sql,
  userId: string,
  hint?: { name?: string | null; email?: string | null; image?: string | null },
) {
  const existing = await sql.query<{ user_id: string }>(
    `select user_id from profiles where user_id = $1`,
    [userId],
  );
  if (existing[0]) return;

  const base =
    slugify(hint?.name || hint?.email?.split("@")[0] || "autor") || "autor";
  let username = base;
  for (let i = 0; i < 12; i += 1) {
    const clash = await sql.query<{ n: number }>(
      `select 1 as n from profiles where username = $1`,
      [username],
    );
    if (!clash[0]) break;
    username = `${base}-${Math.floor(1000 + Math.random() * 9000)}`;
  }
  const display = (hint?.name || hint?.email || "Autor").trim() || "Autor";
  await sql.query(
    `insert into profiles (user_id, username, display_name, avatar_url)
     values ($1, $2, $3, $4)
     on conflict (user_id) do nothing`,
    [userId, username, display.slice(0, 80), hint?.image ?? null],
  );
}

export async function uniqueSlug(sql: Sql, title: string): Promise<string> {
  const base = slugify(title);
  let slug = base;
  for (let i = 0; i < 20; i += 1) {
    const clash = await sql.query<{ n: number }>(`select 1 as n from novels where slug = $1`, [slug]);
    if (!clash[0]) return slug;
    slug = `${base}-${Math.floor(1000 + Math.random() * 9000)}`;
  }
  return `${base}-${Date.now().toString(36)}`;
}
