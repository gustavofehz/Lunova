import { asStringArray, parseContent, type ChapterContent, type ChapterDetail, type ChapterMeta, type NovelCard, type NovelStatus } from "@/lib/types";

export type NovelRow = {
  id: string;
  slug: string;
  title: string;
  synopsis: string;
  cover_url: string | null;
  author_id: string;
  author_name: string;
  author_username: string;
  pen_name: string;
  genres: unknown;
  tags: unknown;
  age_rating: string;
  status: string;
  likes_count: number;
  chapter_count: number;
  rating_avg: number | string | null;
  rating_count: number;
  featured: boolean;
  published: boolean;
  created_at: string;
  updated_at: string;
};

export function mapNovel(row: NovelRow): NovelCard {
  const avgRaw = row.rating_avg;
  const avg =
    avgRaw === null || avgRaw === undefined
      ? null
      : Number(avgRaw);
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    synopsis: row.synopsis ?? "",
    coverUrl: row.cover_url,
    authorId: row.author_id,
    authorName: row.author_name,
    authorUsername: row.author_username,
    penName: row.pen_name ?? "",
    genres: asStringArray(row.genres),
    tags: asStringArray(row.tags),
    ageRating: row.age_rating,
    status: row.status as NovelStatus,
    likesCount: Number(row.likes_count) || 0,
    chapterCount: Number(row.chapter_count) || 0,
    ratingAvg: avg !== null && Number.isFinite(avg) ? avg : null,
    ratingCount: Number(row.rating_count) || 0,
    featured: Boolean(row.featured),
    published: Boolean(row.published),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

export const NOVEL_SELECT = `
  n.id, n.slug, n.title, n.synopsis, n.cover_url, n.author_id,
  coalesce(nullif(n.pen_name, ''), p.display_name) as author_name,
  p.username as author_username,
  n.pen_name,
  n.genres, n.tags, n.age_rating, n.status,
  n.likes_count,
  n.featured, n.published, n.created_at, n.updated_at,
  (select count(*)::int from chapters c where c.novel_id = n.id and c.status = 'published') as chapter_count,
  (select avg(stars)::float from ratings r where r.novel_id = n.id) as rating_avg,
  (select count(*)::int from ratings r where r.novel_id = n.id) as rating_count
`;

export function mapChapterMeta(row: {
  id: string;
  novel_id: string;
  title: string;
  sort_order: number;
  status: string;
  word_count: number;
  published_at: string | null;
  updated_at: string;
}): ChapterMeta {
  return {
    id: row.id,
    novelId: row.novel_id,
    title: row.title,
    sortOrder: Number(row.sort_order),
    status: row.status as ChapterMeta["status"],
    wordCount: Number(row.word_count) || 0,
    publishedAt: row.published_at,
    updatedAt: String(row.updated_at),
  };
}

export function mapChapterDetail(
  row: Parameters<typeof mapChapterMeta>[0] & { content: unknown },
): ChapterDetail {
  return {
    ...mapChapterMeta(row),
    content: parseContent(row.content) as ChapterContent,
  };
}
