export type TextAlign = "left" | "center" | "right" | "justify";
export type ImageAlign = "left" | "center" | "right";
export type NovelStatus = "ongoing" | "completed" | "paused";
export type ChapterStatus = "draft" | "published";
export type Shelf = "reading" | "want" | "completed";

export type ChapterBlock =
  | { id: string; type: "paragraph"; html: string; align: TextAlign }
  | { id: string; type: "heading"; level: 2 | 3; text: string }
  | { id: string; type: "scene-break" }
  | {
      id: string;
      type: "image";
      src: string;
      align: ImageAlign;
      width: number;
      caption: string;
    };

export type ChapterContent = { blocks: ChapterBlock[] };

export type NovelCard = {
  id: string;
  slug: string;
  title: string;
  synopsis: string;
  coverUrl: string | null;
  authorId: string;
  authorName: string;
  authorUsername: string;
  penName: string;
  genres: string[];
  tags: string[];
  ageRating: string;
  status: NovelStatus;
  likesCount: number;
  chapterCount: number;
  ratingAvg: number | null;
  ratingCount: number;
  featured: boolean;
  published: boolean;
  createdAt: string;
  updatedAt: string;
};

export type ChapterMeta = {
  id: string;
  novelId: string;
  title: string;
  sortOrder: number;
  status: ChapterStatus;
  wordCount: number;
  publishedAt: string | null;
  updatedAt: string;
};

export type ChapterDetail = ChapterMeta & {
  content: ChapterContent;
};

export type ProfilePublic = {
  userId: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string | null;
  followers: number;
  following: number;
  novelCount: number;
  createdAt: string;
};

export type CommentItem = {
  id: string;
  userId: string;
  displayName: string;
  username: string;
  avatarUrl: string | null;
  body: string;
  createdAt: string;
};

export type LibraryEntry = NovelCard & {
  shelf: Shelf;
  isFavorite: boolean;
};

export function emptyContent(): ChapterContent {
  return {
    blocks: [
      {
        id: crypto.randomUUID?.() ?? `b-${Date.now()}`,
        type: "paragraph",
        html: "",
        align: "left",
      },
    ],
  };
}

export function parseContent(raw: unknown): ChapterContent {
  if (!raw || typeof raw !== "object") return emptyContent();
  const blocks = (raw as { blocks?: unknown }).blocks;
  if (!Array.isArray(blocks) || blocks.length === 0) return emptyContent();
  return { blocks: blocks as ChapterBlock[] };
}

export function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.map(String);
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed.map(String) : [];
    } catch {
      return [];
    }
  }
  return [];
}

export function displayedAuthor(novel: {
  penName?: string | null;
  authorName: string;
}): string {
  return novel.penName?.trim() || novel.authorName;
}
