import type { ChapterBlock, ChapterContent } from "./types";

const ALLOWED = new Set(["B", "I", "EM", "STRONG", "BR"]);

export function sanitizeHtml(html: string): string {
  if (typeof document === "undefined") {
    return html
      .replace(/<(?!\/?(?:b|i|em|strong|br)\b)[^>]*>/gi, "")
      .replace(/\son\w+="[^"]*"/gi, "");
  }
  const wrap = document.createElement("div");
  wrap.innerHTML = html;
  const walk = (node: Node) => {
    const children = [...node.childNodes];
    for (const child of children) {
      if (child.nodeType === Node.ELEMENT_NODE) {
        const el = child as HTMLElement;
        if (!ALLOWED.has(el.tagName)) {
          const parent = el.parentNode;
          if (!parent) continue;
          while (el.firstChild) parent.insertBefore(el.firstChild, el);
          parent.removeChild(el);
        } else {
          for (const attr of [...el.attributes]) el.removeAttribute(attr.name);
          walk(el);
        }
      }
    }
  };
  walk(wrap);
  return wrap.innerHTML;
}

export function plainText(html: string): string {
  return html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/\s+/g, " ")
    .trim();
}

export function wordCountOf(content: ChapterContent): number {
  let n = 0;
  for (const b of content.blocks) {
    if (b.type === "paragraph") {
      const t = plainText(b.html);
      if (t) n += t.split(/\s+/).length;
    } else if (b.type === "heading") {
      const t = b.text.trim();
      if (t) n += t.split(/\s+/).length;
    }
  }
  return n;
}

export function newBlockId(): string {
  return crypto.randomUUID();
}

export function newParagraph(html = "", align: ChapterBlock extends { align: infer A } ? A : never = "left" as never): Extract<ChapterBlock, { type: "paragraph" }> {
  return { id: newBlockId(), type: "paragraph", html, align: (align as "left") || "left" };
}

export function isContentEmpty(content: ChapterContent): boolean {
  return content.blocks.every((b) => {
    if (b.type === "paragraph") return plainText(b.html).length === 0;
    if (b.type === "heading") return b.text.trim().length === 0;
    if (b.type === "image") return !b.src;
    return true;
  });
}
