import { ALLOWED_IMAGE_MIMES } from "./constants";

function mimeFromName(name: string): string | null {
  const n = name.toLowerCase();
  if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
  if (n.endsWith(".png")) return "image/png";
  if (n.endsWith(".webp")) return "image/webp";
  return null;
}

export function isAllowedImage(file: File): boolean {
  if ((ALLOWED_IMAGE_MIMES as readonly string[]).includes(file.type)) return true;
  return mimeFromName(file.name) !== null;
}

async function loadBitmap(file: File): Promise<ImageBitmap | HTMLImageElement> {
  if (typeof createImageBitmap === "function") {
    try {
      return await createImageBitmap(file);
    } catch {
      /* fall through to HTMLImageElement */
    }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = "async";
    await new Promise<void>((resolve, reject) => {
      img.onload = () => resolve();
      img.onerror = () => reject(new Error("Não foi possível ler a imagem."));
      img.src = url;
    });
    return img;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function canvasToJpeg(canvas: HTMLCanvasElement, quality: number): { data: string; dataUrl: string } {
  const dataUrl = canvas.toDataURL("image/jpeg", quality);
  const comma = dataUrl.indexOf(",");
  return { dataUrl, data: comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl };
}

/** Target payload that fits comfortably under typical server-fn body limits. */
const MAX_B64_CHARS = 900_000;

export async function compressImageFile(
  file: File,
  maxWidth = 1400,
): Promise<{ mime: string; data: string; dataUrl: string }> {
  if (!isAllowedImage(file)) {
    throw new Error("Formato não suportado. Use JPG, JPEG, PNG ou WEBP.");
  }
  const bitmap = await loadBitmap(file);
  const srcW = "width" in bitmap ? bitmap.width : (bitmap as HTMLImageElement).naturalWidth;
  const srcH = "height" in bitmap ? bitmap.height : (bitmap as HTMLImageElement).naturalHeight;

  let widthCap = maxWidth;
  let quality = 0.82;
  let last: { data: string; dataUrl: string } | null = null;

  for (let attempt = 0; attempt < 6; attempt += 1) {
    const scale = Math.min(1, widthCap / Math.max(srcW, 1));
    const w = Math.max(1, Math.round(srcW * scale));
    const h = Math.max(1, Math.round(srcH * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Não foi possível processar a imagem.");
    ctx.fillStyle = "#f3efe6";
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(bitmap as CanvasImageSource, 0, 0, w, h);
    last = canvasToJpeg(canvas, quality);
    if (last.data.length <= MAX_B64_CHARS) {
      if ("close" in bitmap && typeof bitmap.close === "function") bitmap.close();
      return { mime: "image/jpeg", data: last.data, dataUrl: last.dataUrl };
    }
    quality = Math.max(0.52, quality - 0.1);
    widthCap = Math.round(widthCap * 0.78);
  }

  if ("close" in bitmap && typeof bitmap.close === "function") bitmap.close();
  throw new Error("Imagem grande demais. Tente outra com menor resolução.");
}
